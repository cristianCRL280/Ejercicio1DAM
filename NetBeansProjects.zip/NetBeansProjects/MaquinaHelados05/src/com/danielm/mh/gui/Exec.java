/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.danielm.mh.gui;

import com.danielm.mh.biz.MaquinaHelados;
import com.danielm.mh.exceptions.*;
import com.danielm.mh.pojo.*;
import java.util.*;

/**
 *
 * @author enriquenogal
 */
public class Exec {

    public static void main(String[] args) throws Exception {
        Scanner sc = new Scanner(System.in);
        String resp = "";
        MaquinaHelados mh = new MaquinaHelados();

        do {
            System.out.println("------------------------------------------Menú principal------------------------------------------");
            System.out.println("'Helados' para ver los helados.");
            System.out.println("'Ingresar' para ingresar dinero.");
            System.out.println("'Comprar' para comprar un helado.");
            System.out.println("'Apagar' para terminar.");
            System.out.println("¿Qué deseas? --> ");

            resp = sc.nextLine();

            do {

                if (!(resp.equalsIgnoreCase("Helados") || resp.equalsIgnoreCase("Ingresar") || resp.equalsIgnoreCase("Comprar")
                        || resp.equalsIgnoreCase("Apagar"))) {
                    System.out.println("Texto no válido.");
                    System.out.print("Introduce otra vez: ");
                    resp = sc.nextLine();
                }

            } while (!(resp.equalsIgnoreCase("Helados") || resp.equalsIgnoreCase("Ingresar") || resp.equalsIgnoreCase("Comprar")
                    || resp.equalsIgnoreCase("Apagar")));
            if (!resp.equalsIgnoreCase("Apagar")) {
                if (resp.equalsIgnoreCase("Helados")) {
                    verHelados(mh);
                } else if (resp.equalsIgnoreCase("Ingresar")) {
                    introducirDinero(sc, mh);
                } else if (resp.equalsIgnoreCase("Comprar")) {
                    comprarHelado(sc, mh);
                }
            }
        } while (!resp.equalsIgnoreCase("Apagar"));
        System.out.println("Se han gastado un total " + mh.getIngresos() + "€");
    }

    public static void verHelados(MaquinaHelados mh) {

        System.out.println("-----Listado de helados------");
        System.out.println(mh);
        System.out.println("-----------------------------");
        System.out.println("Dispones de " + mh.getMonedero() + "€");
        System.out.println("-----------------------------");
    }

    public static void introducirDinero(Scanner sc, MaquinaHelados mh) {
        String resp = "";
        do {

            System.out.println("Introduzca dinero.");
            System.out.println("'A' Para introducir: 0,05€");
            System.out.println("'B' Para introducir: 0,10€");
            System.out.println("'C' Para introducir: 0,20€");
            System.out.println("'D' Para introducir: 0,50€");
            System.out.println("'E' Para introducir: 1,00€");
            System.out.println("'F' Para introducir: 2,00€");
            System.out.println("'Volver' Para volver al menú principal.");
            System.out.print("¿Qué deseas? --> ");
            resp = sc.nextLine();

            do {

                if (!(resp.equalsIgnoreCase("A") || resp.equalsIgnoreCase("B") || resp.equalsIgnoreCase("C")
                        || resp.equalsIgnoreCase("D") || resp.equalsIgnoreCase("E") || resp.equalsIgnoreCase("F")
                        || resp.equalsIgnoreCase("Volver"))) {
                    System.out.println("Texto incorrecto.");
                    System.out.print("Introduce otra vez: ");
                    resp = sc.nextLine();
                }
            } while (!(resp.equalsIgnoreCase("A") || resp.equalsIgnoreCase("B") || resp.equalsIgnoreCase("C")
                    || resp.equalsIgnoreCase("D") || resp.equalsIgnoreCase("E") || resp.equalsIgnoreCase("F") || resp.equalsIgnoreCase("Volver")));

            if (!resp.equalsIgnoreCase("Volver")) {
                if (resp.equalsIgnoreCase("A")) {
                    mh.setMonedero(mh.getMonedero() + 0.5);
                    System.out.println("Has introducido " + mh.getMonedero() + "€");
                } else if (resp.equalsIgnoreCase("B")) {
                    mh.setMonedero(mh.getMonedero() + 0.10);
                    System.out.println("Has introducido " + mh.getMonedero() + "€");
                } else if (resp.equalsIgnoreCase("C")) {
                    mh.setMonedero(mh.getMonedero() + 0.20);
                    System.out.println("Has introducido " + mh.getMonedero() + "€");
                } else if (resp.equalsIgnoreCase("D")) {
                    mh.setMonedero(mh.getMonedero() + 0.50);
                    System.out.println("Has introducido " + mh.getMonedero() + "€");
                } else if (resp.equalsIgnoreCase("E")) {
                    mh.setMonedero(mh.getMonedero() + 1);
                    System.out.println("Has introducido " + mh.getMonedero() + "€");
                } else if (resp.equalsIgnoreCase("F")) {
                    mh.setMonedero(mh.getMonedero() + 2);
                    System.out.println("Has introducido " + mh.getMonedero() + "€");
                }
            }
            System.out.println("------------------------------------------------------------------");

        } while (!resp.equalsIgnoreCase("Volver"));

        System.out.println("Total introducido " + mh.getMonedero() + "€");
        System.out.println("------------------------------------------------------------------");
    }

    public static void comprarHelado(Scanner sc, MaquinaHelados mh) throws Exception {
        String resp;
        Helado heladoComprado;
        System.out.println("Hola, vas a realizar una compra. ");
        System.out.print("Introduce la posición del helado que deseas: ");
        resp = sc.nextLine();
        try {
            heladoComprado = mh.pedirHelado(resp);
            System.out.println("Coja su helado de tipo: " + heladoComprado);
            System.out.println("Recoga su cambio " + mh.getMonedero() + "€");

        } catch (ThereIsNotEnoughMoney e) {
            e.printStackTrace();
        } catch (NotValidPositionException | QuantityExceededException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
