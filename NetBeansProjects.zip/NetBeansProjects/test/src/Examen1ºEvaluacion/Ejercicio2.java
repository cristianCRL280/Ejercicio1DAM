package Examen1ºEvaluacion;

import java.util.Scanner;

public class Ejercicio2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduce un número: ");
        int numero = sc.nextInt();

        if (esBonito(numero)) {
            System.out.println("El número " + numero + " es bonito.");
        } else {
            System.out.println("El número " + numero + " no es bonito.");
        }
    }

    public static boolean esBonito(int numero) {
        return esPalindromo(numero) && esSumaDigitosPrimo(numero);
    }

    public static boolean esPalindromo(int numero) {
        String strNumero = String.valueOf(numero);
        int longitud = strNumero.length();
        for (int i = 0; i < longitud / 2; i++) {
            if (strNumero.charAt(i) != strNumero.charAt(longitud - 1 - i)) {
                return false;
            }
        }
        return true;
    }

    public static boolean esSumaDigitosPrimo(int numero) {
        int suma = sumaDeDigitos(numero);
        return esPrimo(suma);
    }

    public static int sumaDeDigitos(int numero) {
        int suma = 0;
        while (numero != 0) {
            suma += numero % 10;
            numero /= 10;
        }
        return suma;
    }

    public static boolean esPrimo(int numero) {
        if (numero <= 1) {
            return false;
        }
        for (int i = 2; i <= Math.sqrt(numero); i++) {
            if (numero % i == 0) {
                return false;
            }
        }
        return true;
    }
}
