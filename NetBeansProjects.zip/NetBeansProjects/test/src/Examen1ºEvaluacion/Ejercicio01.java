package Examen1ºEvaluacion;

import java.util.Scanner;

public class Ejercicio01 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String texto;
        String textoMasCambiado = "";
        int mayor = 0;

        do {
            System.out.println("Introduce una cadena de texto: ");
            texto = sc.nextLine();

            if (texto.equalsIgnoreCase("FIN")) {
                System.out.println("Adios");
                break;
            }

            String salida = nSilabas(texto);
            System.out.println("Salida: " + salida);

            int cambios = textoMasCambios(texto);
            if (cambios > mayor) {
                mayor = cambios;
                textoMasCambiado = texto;
            }

        } while (!texto.equalsIgnoreCase("FIN"));

        System.out.println("-------------------------------------");
        System.out.println("El texto más cambiado es: " + textoMasCambiado);
    }

    public static String nSilabas(String texto) {
        String[] array = texto.split(" ");
        String str = "";

        for (String word : array) {
            if (word.length() >= 3) {
                str += word + " ";
            }
        }

        return str.trim();
    }

    public static int textoMasCambios(String t) {
        int cont = 0;
        String[] array = t.split(" ");

        for (String word : array) {
            if (word.length() < 3) {
                cont++;
            }
        }

        return cont;
    }
}
