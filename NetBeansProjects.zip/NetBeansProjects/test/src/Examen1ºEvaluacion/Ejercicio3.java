/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Examen1ºEvaluacion;

import java.util.Scanner;

/**
 *
 * @author dev
 */
public class Ejercicio3 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n, i, j;
        int sumaFilas = 0;
        int sumaColumnas = 0;

        double mediaFilas, mediaColumnas;

        System.out.println("Introduzca un numero n: ");
        n = Integer.parseInt(sc.nextLine());

        int a[][] = new int[n][n];
        rellenarAleatorios(a);
        mostrarValores(a);

        System.out.println("Introduce un numero i");

        i = sc.nextInt();
        System.out.println("Introduce un numero j");
        j = sc.nextInt();

        System.out.println("El numero guardado en la posicion i j es: " + a[i][j]);

    // Sumar los valores de la fila i
        for (int valor1 : a[i]) {
            sumaFilas += valor1;
        }

        // Sumar los valores de la columna j
        for (int k = 0; k < n; k++) {
            sumaColumnas += a[k][j];
        }

        mediaFilas = (double) sumaFilas / n;
        mediaColumnas = (double) sumaColumnas / n;
     

        System.out.println();
        System.out.println("la media de los numero de esa columnas " + mediaColumnas);
        System.out.println("la media de los numero de esa fila es: " + mediaFilas);

    }

    public static void rellenarAleatorios(int[][] array) {
        for (int i = 0; i < array.length; i++) {
            for (int j = 0; j < array[i].length; j++) {
                array[i][j] = aleatorio(0, 9);

            }

        }
    }

    public static int aleatorio(int min, int max) {

        return (int) (Math.random() * (max - min + 1) + min);

    }

    public static void mostrarValores(int[][] array) {
        System.out.println("-------------Valores del array---------------");
        for (int i = 0; i < array.length; i++) {
            for (int j = 0; j < array[i].length; j++) {

                System.out.print(array[i][j] + "\t");

            }
            System.out.println();

        }

    }

}
