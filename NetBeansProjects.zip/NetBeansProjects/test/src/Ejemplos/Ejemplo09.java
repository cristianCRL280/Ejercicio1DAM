
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author dev
 */
public class Ejemplo09 {
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
//        
       String s1;
        String s2;
//        
//        System.out.println("Dame un texto: ");
       s1 = sc.nextLine();
//        
//        System.out.println("este es el texto:" + s1);
//        
//        System.out.println("dame dos palabras: ");
s1 = sc.next();
s2 = sc.next();
//        
//        System.out.println("Palabras 1:" + s1);
//        System.out.println("Palabras 2:" + s2);

        int n;
        double d;
        System.out.print("dame un numero entero y uno double");
       n = sc.nextInt();
       d = sc.nextDouble();
        sc.nextLine();
      
//       n = Integer.parseInt(sc.next());
//       d = Double.parseDouble(sc.nextLine();
        System.out.print("Entero: " + n);
        System.out.println("Double: " + d);
        System.out.print("Dame un texto :");
        s1 = sc.nextLine();
        System.out.println("Este es el texto: " + s1);
        
//        
    }
    
    
}
