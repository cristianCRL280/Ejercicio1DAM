/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author dev
 */
public class Ejemplo07 {
    
    public static void main(String[] args) {
        
        int i = suma (5, 8);
        System.out.println(i);
        
        muestraSuma(4,6);
        
        String str = concatenaNumeros(3,4);
        System.out.println(str);
        
        i = suma(5,9);
        System.out.println(i);
        
        int j = 8;
        int k = 10;
        i = suma (j,k);
        System.out.println(i);
        
        int a = 10;
        int b = 12;
        i= suma(a,b);
        System.out.println(i);
        System.out.println(a);
                
    }
        
    
    
    public static int suma(int a,int b) {
        
   int r;
   r = a + b;
   a = 25;
   return r;
   
            
    
}

public static void muestraSuma(int a, int b) {
    
    
    int r = a + b;
    System.out.println(r);
    
    
    
}

public static String concatenaNumeros(int a, int b){
    
    String resultado = "" + a + b;
    
    return resultado;
    
}
}