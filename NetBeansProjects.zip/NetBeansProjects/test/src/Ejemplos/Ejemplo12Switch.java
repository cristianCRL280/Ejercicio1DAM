/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejemplos;

/**
 *
 * @author dev
 */
public class Ejemplo12Switch {

    public static void main(String[] args) {
        int a = 18;
        int b = 10;
        switch (a) {
            case 1:
                System.out.println("Vale 1");
                b = 10;
                break;
            case 12:
                System.out.println("Vale 12");
                break;
            default:
                System.out.println("no vale nada de lo anterior");
        }
    }

}
