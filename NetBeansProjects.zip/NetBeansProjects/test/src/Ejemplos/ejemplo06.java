/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author dev
 */
public class ejemplo06 {

    public static void main(String[] args) {
        String str;

        int n = 5;

        str = "" + n;

        //wrapper class
        byte b = 9;  // Byte
        short s = 8; //Short
        char c = 'a';  //Character
        int i = 99;     //Integer
        long l = 124;   //Long
        float f = 12.5f;    //Float
        double d = 14.888d;     //Double

        str = Integer.toOctalString(i);
        str = Long.toString(l);

        System.out.println(str);

        str = "14";
        i = Integer.parseInt(str);
        l = Long.parseLong(str);
        d = Double.parseDouble(str);
        System.out.println(i);

        i = Character.getNumericValue(c);

        System.out.println(i);

    }

}
