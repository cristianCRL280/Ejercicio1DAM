/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author dev
 */
public class ejemplo05 {
    public static void main(String[] args) {
        
        //wrapper class
        
        byte b = 9;  
        short s = 8; 
        char c = 'a';  
        int i = 99;
        long l = 124;
        float f = 12.5f;
        double d = 14.888d;
        
        d = i;
        i = b;
        
        b = (byte)l;
        d = 14.888d;
        i = (int)d;
        
        
        
        
        System.out.println(i);
        
        double aux1 = i;
        double aux2 = l;
                d = aux1 / aux2;
                
                System.out.println(d);
        
    }
}
