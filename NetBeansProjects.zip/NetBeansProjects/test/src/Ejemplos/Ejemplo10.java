/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author dev
 */
public class Ejemplo10 {
    public static void main(String[] args) {
        String str1 = "   hola pepe   ";
       
        System.out.println(str1.length());
        System.out.println(str1.charAt(0));
        System.out.println(str1.charAt(1));
        
        str1 = str1.toUpperCase();
        System.out.println(str1);
        
        str1 = str1.toLowerCase();
        System.out.println(str1);
        
        int posicion = str1.indexOf("e");
        System.out.println("posicion");
        
        
        str1 = str1.trim();
        System.out.println("***" + str1 + "***");
        
      
        String s1 = "hola";
        String s2 = "hola";
        
        boolean b;
        b = s1.equals(s2);
        System.out.println(b);
        
        
        b = s1.equalsIgnoreCase(s2);
        System.out.println(b);
    }
    
}
