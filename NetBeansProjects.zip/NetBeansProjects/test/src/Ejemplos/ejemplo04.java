/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author dev
 */
public class ejemplo04 {
    public static void main(String[] args) {
        String a = "pepe";
        String b = "Juan";
        
        String c;
        
        c = a + b;
        System.out.println("");
        
        c = a.concat(b);
        System.out.println("c");
        
        int s = 8;
        int t = 5;
        
        c = c + s;
        System.out.println(c);
        
        c = "hola que tal" + (s + t);
        System.out.println(c);
        
        
    }
}
