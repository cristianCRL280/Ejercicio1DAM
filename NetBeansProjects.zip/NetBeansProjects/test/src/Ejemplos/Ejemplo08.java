/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author dev
 */
public class Ejemplo08 {
    
    public static void main(String[] args) {
        
        System.out.println("hola" + "pepe" + 4);
        System.out.print("hola ");
        System.out.print("pepe ");
        System.out.print(4 + "\n");
        System.out.println("--------");
        String str = "\thola \npepe\b 4";
        // \t tabulador
        // \n salto de linea
        // \b borrar un caracter
        System.out.println(str);
        
        double d = 3.14159;
        int n = 3;
        System.out.printf("Este es el valor de pi: %f,  aqui el numero dos: %d%n", d, n);
        System.out.printf("Este es el texto que he obtenido: %s%n", str);
        //%f numeros con decimales
        //%d numeros enteros
        //%s - cadenas de texto
        //%n no hay que sustituirlo - te introduce un salto de linea
        
        System.out.format("hola que tal %d%n", n);
        System.out.format("Pi con dos decimales es: %.2f %n", d);
        System.out.format("el numero es: %02d %n", n);
        
        String str2 = String.format("el numero es: %02d", n);
        
        System.out.println(str2);

    }
    
}
