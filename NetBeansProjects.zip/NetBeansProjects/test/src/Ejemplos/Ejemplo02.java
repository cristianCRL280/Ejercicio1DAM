/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author dev
 */
public class Ejemplo02 {
    public static void main(String[] args) {
        //variable
        
        
        
        
        //primitivos
        //numericos enteros
        byte b; //numericos enteros -128 al 127
        b = 9;
        
        short s; //numerico desde el -32768 al 32767
        
        int i = 8; //numericos desde -2147483648 al 2147483647
        long l; //numericos gigantes
        
        //numericos con decimales 
        float f = 3.12f;
        double d = 4.55d;
        
        //booleanos
        boolean bool = true; //true y false
        
        //caracteres
      //  char caracter = "c";
        
        //java 10
        var v = 9;
        
        //cadena de caracteres 
        
       String str = "juan";
       str = "pepe";
       
        
        
    }
    
    
}
