/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejemplos;

import java.util.Scanner;

/**
 *
 * @author dev
 */
public class EjemploDoWhile {
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        String centinela = "ok";
        
        
        while(centinela.equals("ok")){
            
            System.out.println("Quieres continuar (ok/ko)");
            centinela = sc.nextLine();
        
        
        }
        int i = 0;
        int n = 1;
        while(1 < 3 && n == 1){
            System.out.println("Valor de i: " + i);
            i++;
        }
        for (int j = 0; j < 3; j++) {
            
            System.out.println("Valor de j: " + j);
            
        }
        
    }
}
