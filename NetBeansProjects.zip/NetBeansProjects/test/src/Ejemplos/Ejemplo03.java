/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author dev
 */
public class Ejemplo03 {
    public static void main(String[] args) {
        //operador de asignacion
        final int C = 10; // final significa que no se le puede cambiar el valor en ningun momento
        int a, b, r;
        double d;
        a = 8;
        b = a;
       // C = b; -- no se le puede asignar valor a c por ser final
       
       //operadores aritmeticos
       
       a = 15;
       b = 7;
       
       r = a + b;
       r = a - b;
       r = a * b;
       r = a / b;
       System.out.println(r);
       
       d = 1.8d * a /b;
       System.out.println(d);
       
       r = a % b;
       System.out.println(d);
       
       r++;
       //r = r+ 1;
        System.out.println("r");
        
        r--;
        System.out.println("r");
       
        r += 2;
        System.out.println("r");
        
        r -= 2;
        System.out.println("r");
    }
}
