/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejemplos;

/**
 *
 * @author dev
 */
public class Ejemplo14Math {
    
    public static void main(String[] args) {
        double n = 3.56;
        double m = 6.78;
        double superficie = Math.PI + Math.pow(m, 2);
        
        System.out.println(Math.ceil(n));
        System.out.println(Math.floor(n));
        System.out.println(Math.round(n));
        
        System.out.println(Math.max(n,m));
        System.out.println(Math.min(n, m));
        
        
        System.out.println(Math.sqrt(n));
        
        System.out.println(Math.random());
    }
    
}
