
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author dev
 */
public class Ejercicio02 {
    
    public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    
    int a, resultado;
    
   System.out.println("Introduce un numero");
   
   a = Integer.parseInt(sc.nextLine());
   
   resultado = calculaMultiplicacion(a);
        System.out.println("El area del cuadrado es: " + resultado);
  
}
    
    public static int calculaMultiplicacion(int n1) {
        int r;
        r = n1 * n1;
        return r;
        
    }
  
    
}