
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author dev
 */
public class Ejercicio07 {
    public static void main(String[] args) {
          Scanner sc = new Scanner(System.in);
          
          double nota1, nota2, nota3, nota4, nota5, resultado;
          
          System.out.println("Introduce nota1");
         nota1 = Double.parseDouble(sc.nextLine());
         
          System.out.println("Introduce nota2");
          nota2 = Double.parseDouble(sc.nextLine());
          
          System.out.println("Introduce nota3");
         nota3 = Double.parseDouble(sc.nextLine());
         
          System.out.println("Introduce nota4");
       nota4 = Double.parseDouble(sc.nextLine());
       
          System.out.println("Introduce nota5");
         nota5 = Double.parseDouble(sc.nextLine());
         
         resultado = (nota1 + nota2 + nota3 + nota4 + nota5) /5;
          
         System.out.println("la media es:" + resultado);
    }
    
}
