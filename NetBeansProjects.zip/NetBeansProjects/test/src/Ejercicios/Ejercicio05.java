
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author dev
 */
public class Ejercicio05 {
    public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    
    double a, resultado;
    
   System.out.println("Introduce el radio: ");
   
   a = Double.parseDouble(sc.nextLine());
   
   resultado = calculaMultiplicacion(a);
        System.out.println("El perimetro de un circulo es: " + resultado);
  
}
    
    public static double calculaMultiplicacion(double n1) {
        double r;
        r = 2 * 3.14 * n1;
        
        return r;
    }
  
    
}
