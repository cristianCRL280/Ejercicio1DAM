
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author dev
 */
public class Ejercicio10 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        double metrosseg, radio, area, tiempo;
        int descansos;
        System.out.println("Dame la velocidad en m/s: ");
    metrosseg = Integer.parseInt(sc.nextLine());
    
     System.out.println("Dame el radio de la circunferencia: ");
    radio = Double.parseDouble(sc.nextLine());
        
    area = 4 * 3.1415 * radio;    
    descansos = (int) area / 1000;
    tiempo = area / metrosseg;
    tiempo = tiempo + (descansos * 60);
        System.out.println("Distancia a recorrer: " + area);
        System.out.println("descansos " + descansos);
        System.out.println("tiempo total: " + tiempo);
    }
    
  
}
