/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicios;
//11.- Escribir un programa que pida dos números y que nos diga si el mayor es múltiplo del menor. Es decir, que no se genere resto al dividir el mayor entre el menor. Repite la acción hasta que al menos uno de los dos números introducidos sea cero. Ejemplos:
//Escribe un número: 6

import java.util.Scanner;

//Escribe otro número: 48
//Son múltiplos
/**
 *
 * @author dev
 */
public class Ejercicio22Math {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n1;
        int n2;
        
        
        System.out.println("Dame un numero");

        n1 = sc.nextInt();
     
           System.out.println("Dame un numero");

        n2 = sc.nextInt();
     
        if (n1 > n2) {
            
            System.out.println("es multiplo");
            
        } else {
            
             if (n2 > n1) {
            
            System.out.println("Es multiplo");
            
        } else {
            
            System.out.println("no es multiplo");
             }
             
             
       
        
        
        }
    }
}

