/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicios;
//12.- Genera un programa que pida al usuario un número entero mínimo y un número entero máximo y que devuelva un número entero aleatorio entre ese mínimo 
//y máximo (inclusive). Tras ello pregunta al usuario si quiere volver a generar un número entero aleatorio.
//En caso afirmativo vuelve a realizar la petición de números mínimo y máximo.
////Para ello haz un método que genere números enteros pseudo-aleatorios entre un entero mínimo y un entero máximo (incluidos).

import java.util.Scanner;

//Ejemplo:
//Introduce un número mínimo: 20
//Introduce un número máximo: 30
//Salida: 26
//¿Quieres otro número (S/N)? S
/**
 *
 * @author dev
 */
public class Ejercicio23Math {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int Nminimo;
        int Nmaximo;

        int resultado;
        String respuesta;
        do {

            System.out.println("Dame un numero minimo");

            Nminimo = sc.nextInt();

            System.out.println("Dame un numero maximo");

            Nmaximo = sc.nextInt();

            resultado = aleatorio(Nminimo, Nmaximo);
            System.out.println(resultado);
            System.out.println("Quieres otro numero (S/N)");
            respuesta = sc.nextLine();
        } while (respuesta.equalsIgnoreCase("S"));
        {

        }

    }

    public static int aleatorio(int min, int max) {

        int r = 0;
//        r = (int) (Math.random() * (max + 1));
//        r = (int) (Math.random() * (max + 1) + min);

        r = (int) (Math.random() * (max - min + 1) + min);
        return r;
    }

}
