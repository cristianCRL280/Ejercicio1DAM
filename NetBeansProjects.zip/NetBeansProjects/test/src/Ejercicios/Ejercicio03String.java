/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicios;
//3.- Haz un programa lea un texto que introduzca el usuario por teclado y posteriormente 
//imprima la última letra. Ejemplo:
//
//Introduzca un texto: Hola Pepe

//Salida: e

import java.util.Scanner;

/**
 *
 * @author dev
 */
public class Ejercicio03String {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String entrada = "";
        System.out.println("Introduzca un texto: ");
        entrada = sc.nextLine();
//        System.out.println(entrada.charAt(entrada.length(-1)));
        
        
    }
    
}
