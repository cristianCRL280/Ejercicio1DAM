
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author dev
 */
public class Ejercicio03 {
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        double lado, apotema, area;
        System.out.println("Dame la longitud del lado: ");
        lado = Double.parseDouble(sc.nextLine());
        System.out.println("Dame la longitud de la apotema");
        apotema = Double.parseDouble(sc.nextLine());
        area = ((lado * 5) * apotema) / 2;
        System.out.println("El area es: " + area);
        
        
    }
    
    }
 
