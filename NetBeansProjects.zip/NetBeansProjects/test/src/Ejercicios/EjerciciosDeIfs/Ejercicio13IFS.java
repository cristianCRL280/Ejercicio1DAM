/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicios;
//. Programa que pida un número entero y muestre un mensaje de si el número es par
// o impar.

import java.util.Scanner;

/**
 *
 * @author dev
 */
public class Ejercicio13IFS {
    public static void main(String[] args) {
          Scanner sc = new Scanner(System.in);
        
        double numero;
        System.out.println("Dame un numero: ");
        
        numero = Double.parseDouble(sc.nextLine());
        
        if (numero % 2 == 0) {
            System.out.println("Es par");
        } else {
            System.out.println("Es impar");
        }
    }
}
