/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicios;
//6. Programa que pida un número entero y muestre un mensaje de si el número es
//múltiplo de 7.

import java.util.Scanner;

/**
 *
 * @author dev
 */
public class Ejercico06IFS {
    public static void main(String[] args) {
        
    
     Scanner sc = new Scanner(System.in);  
     int numero;
     
     System.out.println("Dame un numero: ");
     
     numero = Integer.parseInt(sc.nextLine());
     
      if (numero % 7 == 0) {
            System.out.println("Es multiplo de 7");
        } else {
            System.out.println("No es multiplo de 7");
        }
    }
     
}
