/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicios;

//5. Programa que pida un número entero del 1 al 7 visualice el mensaje de “Hoy es
import java.util.Scanner;

// Lunes” si el número es el 1; “Hoy es Martes” si el número es el 2, y así
// sucesivamente.
/**
 *
 * @author dev
 */
public class Ejercicio05IFS {

    public static void main(String[] args) {

        int numero;
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduce un numero entero");

        numero = Integer.parseInt(sc.nextLine());

        switch (numero) {
            case 1:
                System.out.println("Es lunes");
                break;
            case 2:
                System.out.println("Es martes");
                break;
            case 3:
                System.out.println("Es miercoles");
                break;
            case 4:
                System.out.println("Es jueves");
                break;
            case 5:
                System.out.println("Es viernes");
                break;
            case 6:
                System.out.println("Es sabado");
                break;
            case 7:
                System.out.println("Es domingo");
                break;

        }

    }

}
