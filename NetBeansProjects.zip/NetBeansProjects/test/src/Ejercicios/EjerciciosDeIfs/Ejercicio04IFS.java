/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicios;
//4. Programa que pida un número entero y muestre un mensaje de si el número está
// comprendido entre 100 y 500 ambos incluidos.

import java.util.Scanner;

/**
 *
 * @author dev
 */
public class Ejercicio04IFS {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        double numero;
        System.out.println("Dame un numero: ");
        numero = Double.parseDouble(sc.nextLine());
        if (numero >=100 && numero <=500){
            System.out.println("Está en el rango");
        } else {
            
            System.out.println("No está en el rango");
        }
       
    }
}
