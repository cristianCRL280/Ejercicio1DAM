/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicios;
//7. Programa que pida la edad de una persona y muestre un mensaje según lo
//siguiente;

import java.util.Scanner;

//i. si la edad es menor de 13 años muestra “es un niño”
//ii. si la edad está entre 13 y 16 “es un adolescente”
//
//iii. si la edad está entre 17 y 25 “es un Joven”
//
//iv. si la edad es mayor o igual de 26 “es un adulto”


/**
 *
 * @author dev
 */
public class Ejercicio07IFS {
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        int numero;
        System.out.println("Dame una edad: ");
        
        numero = Integer.parseInt(sc.nextLine());
        
         if (numero < 13) {
            System.out.println("Es un niño");

        } else {
            if (numero <=16) {
                System.out.println("Es adolescente");
            } else {
                if (numero <=25) {
                    System.out.println("Es joven");
                } else {
                    System.out.println("Es adulto");
                }
            }

        }
        
    }
    
    
    
}
