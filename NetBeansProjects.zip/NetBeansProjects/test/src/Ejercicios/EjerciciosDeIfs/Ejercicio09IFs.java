/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
//   9. En un Hospital se ha hecho un estudio sobre los pacientes registrados durante los
//últimos 10 años, con el objeto de hacer una aproximación de los costes de estancia
//de un paciente. Se obtuvo un coste promedio diario según el tipo de enfermedad que
// aqueja al paciente. Además se pudo determinar que en promedio todos los
//pacientes con edad entre 14 y 22 años implican un coste adicional del 10%. 
//La
// siguiente tabla expresa los costes diarios, según el tipo de enfermedad.
//Enfermedad tipo 1 - coste 25
//Enfermedad tipo 2 - 16
//Enfermedad tipo 3 - 20
//Enfermedad tipo 4 - 32
//Elabore un algoritmo que calcule e imprima el coste total de un paciente, tenga
//presente que datos debe pedir el programa.    
package Ejercicios;

import java.util.Scanner;

/**
 *
 * @author dev
 */
public class Ejercicio09IFs {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int edad, dias, tipoEnfermedad, costeDiario = 32;
        double costeTotal;
        System.out.println("Introduce el tipo de enfermedad: ");
        tipoEnfermedad = sc.nextInt();
        System.out.println("Introduce los dias de ingreso: ");
        dias = sc.nextInt();
        System.out.println("Introduce la edad del paciente");
        edad = sc.nextInt();

        if (tipoEnfermedad == 1) {
            costeDiario = 25; 
            
        } else if (tipoEnfermedad == 2) {
            costeDiario = 16;
        } else if (tipoEnfermedad == 3) {
            costeDiario = 20;
            
        } else if (tipoEnfermedad == 4) {
            costeDiario = 32;      
    }

            costeTotal = costeDiario * dias;
            
            if (edad >= 14 && edad <= 22){
        
        costeTotal = costeTotal * 1.10d;
    }
            System.out.println("Coste total aproximado: " + costeTotal);
}
}

