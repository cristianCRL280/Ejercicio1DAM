/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicios;
//2. Programa que pida un número entero y muestre un mensaje de si el número es
// positivo, negativo o cero.

import java.util.Scanner;

/**
 *
 * @author dev
 */
public class Ejercicio12IFS {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int numero;

        System.out.println("Dame un numero entero: ");

        numero = Integer.parseInt(sc.nextLine());

        if (numero > 0) {
            System.out.println("Es positivo");

        } else {
            if (numero == 0) {
                System.out.println("Es cero");
            } else {
                if (numero < 0) {
                    System.out.println("Es negativo");
                }
            }

        }
    }
}
