/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicios;

//1. Programa que pida la edad de una persona y muestre un mensaje de si la persona 

import java.util.Scanner;

//es mayor de edad o no.

/**
 *
 * @author dev
 */
public class Ejercicio11IFS {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        int edad;
        System.out.println("Dame la edad: ");
        
        edad = Integer.parseInt(sc.nextLine());
        
        if (edad >= 18) {
            System.out.println("Es mayor de edad");
        } else {
            System.out.println("No es mayor de edad");
        }
        
        
       
    }
    
}
