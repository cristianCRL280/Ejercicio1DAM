/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicios;
//8. Construir un programa que pida el peso (en kg) y la altura (en metros), calcule el
//índice de masa corporal de una persona (IMC = peso [kg] / altura2 [m]) e indique el

import java.util.Scanner;

//estado en el que se encuentra esa persona en función del valor de IMC: 
//menor de  16 Criterio de ingreso en hospital
//de 16 a 17 infrapeso
//de 17 a 18 bajo peso
//de 18 a 25 peso normal (saludable)
//de 25 a 30 sobrepeso (obesidad de grado I)
//de 30 a 35 sobrepeso crónico (obesidad de grado II)
//de 35 a 40 obesidad premórbida (obesidad de grado III)
//mayor de 40 obesidad mórbida (obesidad de grado IV
/**
 *
 * @author dev
 */
public class Ejercicio08IFS {

    public static void main(String[] args) {
        
    
        double IMC, peso, altura;
        Scanner sc = new Scanner(System.in);

        System.out.println("Dame el peso: ");
        peso = Double.parseDouble(sc.nextLine());

        System.out.println("Dame la altura: ");
        altura = Double.parseDouble(sc.nextLine());

        IMC = calculaImc(peso, altura);

        if (IMC < 16) {
            System.out.println("Ingreso de hospital");

        } else {
            if (IMC > 16 && IMC < 17) {
                System.out.println("Infrapeso");
            } else {
                if ( IMC < 18) {
                    System.out.println("Bajo peso");
                } else {
                    if ( IMC < 25) {
                        System.out.println("Peso normal");
                    } else {
                        if ( IMC < 30) {
                            System.out.println("Sobrepeso");
                        } else {
                            if ( IMC < 35) {
                                System.out.println("Sobrepeso cronico");
                            } else {
                                if ( IMC < 40) {
                                    System.out.println("Obesidad premorbida");
                                } else {
                                    System.out.println("Obesidad morbida");
                                }
                            }

                        }

                    }
                }
            }
        }
    }
    
    



    public static double calculaImc(double n1, double n2) {

        double r;

        r = n1 / n2;
        return r;

    }
}

