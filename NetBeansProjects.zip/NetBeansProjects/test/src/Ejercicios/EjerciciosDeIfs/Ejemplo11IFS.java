/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejemplos;

/**
 *
 * @author dev
 */
public class Ejemplo11IFS {

    public static void main(String[] args) {
        int a = 5;
        int b = 19;

        if (a > b && a > 0 && b > 0) {
            System.out.println("Se ha cumplido la condición");
            System.out.println("Asi que bien");
            b = 19;
        } else if (a == b) {
            System.out.println("No se cumple");
            System.out.println("Pero son iguales");
            
        } else if (a < 0 || b < 0) {
            System.out.println("No se cumple");
            System.out.println("Hay un negativo");
            
        } else {
            System.out.println("No se ha cumplido la condicion");
            System.out.println("ASi que mal");
        }
        if (a + b > 10) {
            System.out.println("La suma es mayor de 10");
        }
        String s1 = "hola";
        String s2 = "hola";
        if (s1.equals(s2) && s1.length() == 4){
            System.out.println("Iguales");
            System.out.println("Y de longitud 4");
            
            
        }
    }

}
