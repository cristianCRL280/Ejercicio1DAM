
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author dev
 */
public class Ejercicio06 {
    public static void main(String[] args) {
                Scanner sc = new Scanner(System.in);
                int SegundosIniciales, h, m, s, resto;
                
        System.out.println("Dame un valor en segundos: ");
        SegundosIniciales = Integer.parseInt(sc.nextLine());
        
        h = SegundosIniciales / 3600;
        resto = SegundosIniciales % 3600;
        m = resto / 60;
        s = resto % 60;
        
        System.out.println("Horas: "+ h);
        System.out.println("Minutos: "+ m);
        System.out.println("Segundos: "+ s);
        
    
    
        
   
    }
 
}
    

