import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
//1.- Haz un programa que lea un texto que introduzca el usuario por teclado y que 
//posteriormente muestre el mismo texto pero sustituyendo la palabra pueblo por la palabra
// “Leganés”.
// Ejemplo:
//
//Introduzca un texto: Me gusta mi pueblo, sobre todo en invierno.
// Menudo es mi pueblo
//
//Salida: Me gusta mi Leganés, sobre todo en invierno. Menudo es mi 
//Leganés

/**
 *
 * @author dev
 */
public class Ejercicio01Strings {
    
    public static void main(String[] args) {
         Scanner sc = new Scanner(System.in);
        String entrada, salida;
         
         
        System.out.println("Introduce un texto   ");
       entrada = sc.nextLine();
       salida = entrada.replaceAll("pueblo", "Leganes");
       
        System.out.println("Salida: " + salida);
    }
    
}
