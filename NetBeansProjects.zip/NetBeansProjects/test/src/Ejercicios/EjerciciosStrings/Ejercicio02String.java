/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicios;

//2.- Haz un programa que lea un texto que introduzca el usuario por teclado y posteriormente un
//número de inicio y número de final. Posteriormente debe imprimir por pantalla ese texto desde 
//la posición inicio hasta la posición final.
// Ejemplo:
//
//Introduzca un texto: Hola Pepe
//
//Inicio: 2
//
//Final: 6
//
//Salida: la P
//


import java.util.Scanner;

/**
 *
 * @author dev
 */
public class Ejercicio02String {
    public static void main(String[] args) {
         Scanner sc = new Scanner(System.in);
         String entrada, salida;
            
         int inicio, fin;
         
         System.out.println("Introduzca un texto ");
         entrada = sc.nextLine();
         System.out.println("inicio");
         inicio = Integer.parseInt(sc.nextLine());
         System.out.println("Fin");
         fin = Integer.parseInt(sc.nextLine());
         
         salida = entrada.substring(inicio, fin);
         System.out.println("salida: " + salida);
         //tratar texto desde donde se empieza hasta donde acaba si no se pone endIndex cuenta hasta el final automaticamente
    }
}
