
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author dev
 */
public class Ejercicio09 {
    public static void main(String[] args) {
        
   
     Scanner sc = new Scanner(System.in);
    
     int EurosIni, quinientos, cien, cincuenta, veinte, resto, resultado;
     System.out.println("Dame un valor en euros: ");
     EurosIni = Integer.parseInt(sc.nextLine());
     
     quinientos = EurosIni / 500;
     
     resto = quinientos % 100;
     
     cien = resto / 100;
     
     cincuenta = cien / 50;
             
      veinte = cincuenta / 20;
      
      
     
     
     System.out.println("quinientos: "+ quinientos);
        System.out.println("cien: "+ cien);
        System.out.println("cincuenta: "+ cincuenta);
        System.out.println("veinte: "+ veinte);
     }
}
