
import java.util.Scanner;




/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author dev
 */
public class Ejercicio04 {
    public static void main(String[] args) {
       Scanner sc = new Scanner(System.in);
        
       int a, b, resultado;
        System.out.println("Introduce el año actual");
        a = Integer.parseInt(sc.nextLine());
        
         System.out.println("Introduce el año de nacimiento");
        b = Integer.parseInt(sc.nextLine());
        resultado = calculaResta(a,b);
        System.out.println("Tu edad  es:" + resultado);
        
    }
    
    public static int calculaResta(int n1, int n2){
        
        int r;
        
        r = n1 - n2;
             
         return r;

    
}
}

