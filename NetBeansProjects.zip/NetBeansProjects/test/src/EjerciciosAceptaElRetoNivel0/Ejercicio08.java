/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package EjerciciosAceptaElRetoNivel0;

import java.util.Scanner;

/**
 *
 * @author dev
 */
public class Ejercicio08 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        int aAbuelo, aIglesia;

        do {

            aAbuelo = sc.nextInt();
            aIglesia = sc.nextInt();

            if (aAbuelo != 0 && aIglesia != 0) {

                if (aAbuelo < aIglesia) {
                    System.out.println("SENIL");

                }
                if (aAbuelo >= aIglesia) {

                    System.out.println("CUERDO");
                }
                if (aAbuelo == aIglesia) {

                    System.out.println("CUERDO");
                }

            }

        } while (aAbuelo != 0 && aIglesia != 0);

    }

}
