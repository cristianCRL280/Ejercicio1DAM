/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package EjerciciosAceptaElRetoNivel0;

import java.util.Scanner;

/**
 *
 * @author dev
 */
public class Ejercicio09 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int nVeces;

        String numero = "";

        nVeces = Integer.parseInt(sc.nextLine());
        for (int i = 0; i < nVeces; i++) {

            numero = sc.nextLine();

            if (numero.length() == 3) {
                System.out.println(numero.charAt(0));

            }
            if (numero.length() == 4) {
                System.out.print(numero.charAt(0));
                System.out.println(numero.charAt(1));

            }
            if (numero.length() == 5) {
                System.out.print(numero.charAt(0));
                System.out.print(numero.charAt(1));
                System.out.println(numero.charAt(2));

            }
            if (numero.length() == 6) {
                System.out.print(numero.charAt(0));
                System.out.print(numero.charAt(1));
                System.out.print(numero.charAt(2));
                System.out.println(numero.charAt(3));

            }

        }

    }
}
