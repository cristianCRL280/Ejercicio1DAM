/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package EjerciciosAceptaElRetoNivel0;

import java.util.Scanner;

/**
 *
 * @author dev
 */
public class Ejercicio07 {
    public static void main(String[] args) {
          Scanner sc = new Scanner(System.in);

        int n;

        int pNeto, pTotal, total;

        n = sc.nextInt();

        for (int i = 0; i < n; i++) {

            pNeto = sc.nextInt();
            pTotal = sc.nextInt();
          
            total = pTotal - pNeto;
            
            System.out.println(total);
           
        }
        
        
        
    }
    
}
