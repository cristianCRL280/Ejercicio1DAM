/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package EjerciciosAceptaElRetoNivel0;

import java.util.Scanner;

/**
 *
 * @author dev
 */
public class Ejercicio10 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int nVeces;
        int nPagina;

        nVeces = sc.nextInt();

        for (int i = 0; i < nVeces; i++) {

            nPagina = sc.nextInt();

            if (nPagina % 2 == 0) {
                
                System.out.println(nPagina + 1);
                
            } else {
                
                System.out.println(nPagina - 1);
            }
            
            
            
        }

    }
}
