
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
// */
//Realizar un programa (llama al fichero Ejercicio03.java) que realice las siguientes acciones:
//Pida al usuario un número y lo guarde en una variable n. El usuario introducirá un número entero positivo (no
//hace falta que lo compruebes)
//Genere una matriz bidimensional de int, de dimensiones n x n, y que posteriormente rellene el marco y la
//diagonal principal con el número 1 y el resto con el número 0. (2 puntos)
//Imprima por pantalla a través de un método al que le llegará como parámetro la matriz generada anteriormente,
//el contenido de la matriz en filas y columnas. (0,5 puntos)
//Repite esta acción hasta que el usuario introduzca un número menor o igual a cero (0,5 puntos).
/**
 *
 * @author dev
 */
public class Ejercicio03Examen {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n;

        char[][] a;

        do {
            System.out.println("Introduzca un numero: ");
            n = sc.nextInt();
            if (n > 0) {
                a = new char[n][n];
                rellenarArray(a, n);
                mostrarArray(a);

            }
            
            
            
            

        } while (n > 0);
        System.out.println("adios");

    }

    public static void rellenarArray(char[][] a, int n) {

        for (int fila = 0; fila < a.length; fila++) {

            for (int columna = 0; columna < a[fila].length; columna++) {
                a[fila][columna] = '0';

                if (fila == columna || fila == 0 || columna == 0 || fila == n - 1
                        || columna == n - 1) {

                    a[fila][columna] = '1';

                } else {

                    a[fila][columna] = '0';
                }

            }

        }

    }

    public static void mostrarArray(char[][] a) {

        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[i].length; j++) {
                System.out.print(a[i][j] + " ");

            }
            System.out.println();
        }
    }

}
