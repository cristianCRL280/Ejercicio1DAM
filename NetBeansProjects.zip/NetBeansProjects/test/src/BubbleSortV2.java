
import java.util.Arrays;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author dev
 */
public class BubbleSortV2 {

    public static void main(String[] args) {
        
        int[] arr = {12, 13, 14, -1, 26, 5};
        sort(arr, arr.length);
        
        System.out.println(Arrays.toString(arr));
        
    }

    static void sort(int[] arr, int n) {
        int key;
        
        for (int i = 0; i < n; i++) {
            key = arr[i];
            int j = i;
            while (j > 0 && arr[i] > key) {
                arr[j] = arr[j + 1];
              
               
            }
            
        }
         
    }

}
