/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicios;

import java.util.Scanner;

//6 .- Pide al usuario un número double. 
//Posteriormente genera un array de double de 20 posiciones. 
//En la primera posición del array guarda el número introducido por el usuario anteriormente. Las siguientes posiciones tienen que ser rellenadas por la mitad del valor de la posición anterior.
//Muestra el contenido del array.

/**
 *
 * @author dev
 */
public class EjercicioArrays6 {
    public static void main(String[] args) {
        
       Scanner sc = new Scanner(System.in);
        System.out.println("Dame un numero: ");
        
       double d = sc.nextDouble();
       double[] a = new double[20];
      rellenar(d, a);
        for (double e : a) {
            System.out.println(" " + e);
            
        }
        System.out.println();
    }
    
    
    public static void rellenar(double d, double[] a){
        
        a[0] = d;
        for (int i = 1; i < a.length; i++) {
            a[i] = a[i - 1] / 2;
            
        }
        
    }
}
