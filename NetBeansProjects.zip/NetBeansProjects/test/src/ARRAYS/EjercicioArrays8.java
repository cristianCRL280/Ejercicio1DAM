/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicios;

import java.util.Scanner;
//8.- Genera un array de enteros de 20 posiciones. 
//Posteriormente rellena ese array con números aleatorios del -10 al 10. 
//Muestra el contenido del array
//Muestra el número mayor, su posición. 
//Muestra el número menor y su posición. 
//En caso de empate muestra la posición del último número mayor o menor.

/**
 *
 * @author dev
 */
public class EjercicioArrays8 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
       int menor = Integer.MAX_VALUE, mayor = Integer.MIN_VALUE, posMenor = 0, posMayor= 0;
         int [] a = new int[20];
         rellenarAleatorios(a);
         System.out.println("Contenido: ");
         for (int i = 0; i < a.length; i++) {
             System.out.println("Posicion " + i + ":" + a[i]);
             if (a[i] <= menor) {
                 menor = a[i];
                 posMenor = i;
                 
             }
             if (a[i] >= mayor){
                 mayor = a[i];
                 posMayor = i;
             }
            
        }
         
         System.out.println("Mayor: " + mayor + " posicion " + posMayor);
          System.out.println("Menor: " + menor + " posicion " + posMenor);
    }
    
    
    
    
    
            public static void rellenarAleatorios(int[] array) {
        for (int i = 0; i < array.length; i++) {

            array[i] = aleatorio(-10, 10);

        }
        

    }
            public static int aleatorio(int min, int max) {

        return (int) (Math.random() * (max - min + 1) + min);

    }
}
