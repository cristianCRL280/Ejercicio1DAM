/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicios;

import java.util.Scanner;

/**
 *
 * @author dev
 */
public class EjercicioArrays1 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int[] a = new int[20];
        rellenarAleatorios(a);
        modificarValores(a);
        mostarContenidoArray(a);
    }

    public static void modificarValores(int[] array) {

        for (int i = 0; i < array.length; i++) {

            if (array[i] < 0) {

                array[i] = 1;

            }

        }

    }

    public static void mostarContenidoArray(int[] array) {

        System.out.println("------------------Contenido del array --------------");

        for (int i = 0; i < array.length; i++) {

            System.out.println("Posicion " + i + ":" + array[i]);

        }

    }

    public static void rellenarAleatorios(int[] array) {
        for (int i = 0; i < array.length; i++) {

            array[i] = aleatorio(-10, 10);

        }

    }

    public static int aleatorio(int min, int max) {

        return (int) (Math.random() * (max - min + 1) + min);

    }
}
