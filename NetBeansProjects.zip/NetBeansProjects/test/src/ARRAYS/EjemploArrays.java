/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejemplos;

/**
 *
 * @author dev
 */
public class EjemploArrays {

    public static void main(String[] args) {
        int[] aInt1 = {2, 5, 7, 9};
        String[] aString1 = {"pepe", "juan", "antonio", "miguel"};

        int longitud = 4;

        int[] aInt2;
        aInt2 = new int[longitud];

        aInt1[0] = 9;

        System.out.println("El valor de aInt1 en su posicion 0: " + aInt1[0]);

        aInt2[0] = 18;

        System.out.println("El valor de aInt2 en su posicion 0: " + aInt2[3]);
        System.out.println("La longitud de mi array aINT1: " + aInt1.length);

        mostrarSuma1(aInt1);
        mostrarSuma2(aInt1);
    }

    public static void mostrarSuma1(int[] a) {
        int suma = 0;
        for (int i = 0; i < a.length; i++) {

            System.out.println("El valor del array en la posicion " + i + "es: " + a[i]);

            suma += a[i];

            System.out.println("LLevo acumulado: " + suma);

        }

        System.out.println("La suma de los valores es : " + suma);

    }

    public static void mostrarSuma2(int[] a) {
        int suma = 0;
        for (int valor : a) {

            suma += valor;

        }

        System.out.println("La suma de los valores es : " + suma);

    }
}
