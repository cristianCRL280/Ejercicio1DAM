/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicios;
//10.- Realiza un programa que lea del teclado una línea de texto y posteriormente separe estas líneas de texto por el carácter separador “,”, y finalmente muestre los textos separados en líneas diferentes. 
//Usa el método split de String y guarda el resultado en un array de Strings. 

import java.util.Scanner;

//Posteriormente recorre cada una de las posiciones del array e imprimelo línea por línea.
//Ejemplo:
//
//Introduzca un texto: Hola, me llamo Enrique, soy de Leganés, nací en el 76
//Hola
// me llamo Enrique
// soy de Leganés
// nací en el 76
/**
 *
 * @author dev
 */
public class EjercicioArray10 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("Dame un texto: ");
        String texto = sc.nextLine();
        String[] subTextos = texto.split(",");
        System.out.println("Salida:");

        for (String subTexto : subTextos) {

            System.out.println(subTexto);

        }

    }

}
