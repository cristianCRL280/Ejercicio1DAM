/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicios;

//
import static Ejercicios.EjercicioArrays3.aleatorio;
import java.util.Scanner;

//Pide al usuario un número entero.
//Genera un array de enteros de tantas posiciones como haya introducido el usuario anteriormente.
//Posteriormente rellena ese array con números aleatorios del -10 al 10. 
//Muestra el contenido del array.
//Da la vuelta al array, de modo que el contenido de la primera posición se aloje en la última posición y viceversa, el de la segunda posición en la penúltima posición y viceversa, y así hasta que termine totalmente volteada.
//Muestra de nuevo el contenido del array.
/**
 *
 * @author dev
 */
public class EjercicioArray4 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n;
        System.out.println("Introduzca un numero entero: ");
        n = sc.nextInt();
        int a[] = new int[n];
        rellenarAleatorios(a);
        mostrarContenidoArray(a);
       a = darLaVuelta1(a);
           mostrarContenidoArray(a);
    }

    public static void rellenarAleatorios(int[] array) {
        for (int i = 0; i < array.length ; i++) {

            array[i] = aleatorio(-10, 10);

           
        }
    }

    public static int aleatorio(int min, int max) {

        return (int) (Math.random() * (max - min + 1) + min);

    }
    
 
     public static int []darLaVuelta1(int[] array) {

      int[] r = new int[array.length];
      
      int t = array.length - 1;
        for (int i = 0; i < array.length; i++) {
            
            r[t] = array[i];
            
            t--;
            
        }
      
      return r;

}
         public static void mostrarContenidoArray(int[] array) {

        System.out.println("------------------Contenido del array --------------");

        for (int valor : array) {

            System.out.println(" " + valor);

        }
             System.out.println();
    }
}