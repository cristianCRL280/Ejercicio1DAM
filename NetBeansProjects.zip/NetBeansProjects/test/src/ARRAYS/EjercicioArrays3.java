/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicios;

import static Ejercicios.EjercicioArrays1.aleatorio;
import java.util.Scanner;

/**
 *
 * @author dev
 */
public class EjercicioArrays3 {
    
    public static void main(String[] args) {
         Scanner sc = new Scanner(System.in);
         int n;
         System.out.println("Introduzca un numero entero: ");
         n = sc.nextInt();
         int[] a = new int[n];
         
         rellenarAleatorios(a);
         mostrarContenidoArrayPositivos(a);
         
    }
    
    
    public static void mostrarContenidoArrayPositivos(int[] array){
        
        for (int i = 0; i < array.length; i++) {
            
            if (array[i] > 0) {
                
                System.out.println("Posicion " + i +  ": " + array[i] + "-- es positivo");
                
                
            }
            
        }
        
    }
    
    
    
     public static int aleatorio(int min, int max) {

        return (int) (Math.random() * (max - min + 1) + min);

    }
     
     public static void rellenarAleatorios(int[] array) {
        for (int i = 0; i < array.length; i++) {

            array[i] = aleatorio(-10, 10);

        }

    }
}
