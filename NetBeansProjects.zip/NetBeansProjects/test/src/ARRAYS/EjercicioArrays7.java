/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicios;

import java.util.Scanner;
//7.- Genera un array de enteros de 20 posiciones. 
//Posteriormente rellena ese array con números aleatorios del -10 al 10. 
//Muestra el contenido del array.
//Finalmente muestra la suma de los valores y el valor medio.
/**
 *
 * @author dev
 */
public class EjercicioArrays7 {
    public static void main(String[] args) {
         Scanner sc = new Scanner(System.in);
         int suma = 0;
         double media;
         int [] a = new int[20];
         rellenarAleatorios(a);
         System.out.println("Contenido: ");
         for (int valor : a) {
             System.out.println(" " + valor);
            suma += valor;
        }
         System.out.println();
         media = 1.0d * suma / a.length;
         System.out.println("Suma de valores: " + suma);
         System.out.println("Media de los valores: " + media);
    }
        public static void rellenarAleatorios(int[] array) {
        for (int i = 0; i < array.length; i++) {

            array[i] = aleatorio(-10, 10);

        }
        

    }
        public static int aleatorio(int min, int max) {

        return (int) (Math.random() * (max - min + 1) + min);

    }
}
