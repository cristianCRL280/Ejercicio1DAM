/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicios;

import java.util.Scanner;


//9 .- Pide al usuario un número entero. 
//Genera un array con los números de la serie Fibonacci hasta
//la iteración correspondiente al número introducido por el usuario.
//Muestra el contenido del array.
/**
 *
 * @author dev
 */
public class EjercicioArrayFibonacci {
    
    public static void main(String[] args) {
          Scanner sc = new Scanner(System.in);
    
        System.out.println("Dame un numero entero: ");
        int n = sc.nextInt();
        int[] a = fibonacci(n);
    
        System.out.println("fibonacci: ");
        
        for (int valor : a) {
            
            System.out.println(" " + valor);
            
        }
        
        System.out.println();
    
}
    
    
    public static int [] fibonacci(int n){
        
        int[] r = new int[n];
        
        r[0] = 1;
        r[1] = 1;
        
        for (int i = 2; i <r.length ; i++) {
            
            r[i] = r[i - 1] + r[i - 2];
            
        }
        
        return r;
        
        
    }
}