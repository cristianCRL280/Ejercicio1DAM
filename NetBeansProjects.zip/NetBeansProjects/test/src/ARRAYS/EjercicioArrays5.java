/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicios;

import java.util.Scanner;

/**
 *
 * @author dev
 */
//5.-  Pide al usuario un número entero.
//Genera un array de enteros de tantas posiciones como haya introducido el usuario anteriormente.
//Pide de nuevo un número entero al usuario (número límite).
//Rellena el array de modo que la posición cero tenga un número 0, la posición uno un 1 y así sucesivamente, hasta que el valor previo al número límite. En ese momento ese valor debe volver a 0 y seguir rellenando de este modo.
//Muestra el contenido del array.
//Ejemplo
//
//Introduce un número: 7
//Introduce un número límite: 3
//Salida
//posición 0: 0 
//posición 1: 1 
//posición 2: 2 
//posición 3: 0 
//posición 4: 1 
//posición 5: 2 
//posición 6: 0 
public class EjercicioArrays5 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n, limite, valor = 0;
        System.out.println("numero de veces: ");
        n = sc.nextInt();
          System.out.println("introduce un numero limite: ");
        limite = sc.nextInt();
       
        
        int [] a = new int[n];
        
        for (int i = 0; i < a.length; i++) {
            
            a[i] = valor;
            valor++;
            if (valor == limite) {
                
                valor = 0;
                
            }
            
        }
        
        System.out.println("Salida: ");
        for (int valorPosicionArray : a) {
            System.out.println(" " + valorPosicionArray);
            
        }
        System.out.println();
    }
    
    
    
  
   
}
