/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejemplos;

/**
 *
 * @author dev
 */
public class EjemploArrays2 {
    
    public static void main(String[] args) {
        int n = 12;
        cambiaValor(n);
        
        System.out.println("El valor de n es: " + n);
        
        
    }
    public static void cambiaValorArray(int[] b){
        b[0] = 18;
        
        
    }
    
    
    
    
    public static void cambiaValor (int n){
        
        n = 18;
        
    }
    
}
