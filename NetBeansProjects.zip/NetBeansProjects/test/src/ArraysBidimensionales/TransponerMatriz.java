/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ArraysBidimensionales;

/**
 *
 * @author dev
 * 
 */
public class TransponerMatriz {
    public static void main(String[] args) {
        int[][] matriz = {
            {1, 2, 3},
            {4, 5, 6},
            {7, 8, 9}
        };

        mostrarValores(matriz);
        int[][] transpuesta = transponer(matriz);
        System.out.println("Matriz transpuesta:");
        mostrarValores(transpuesta);
    }

    public static int[][] transponer(int[][] array) {
        int filas = array.length;
        int columnas = array[0].length;
        int[][] transpuesta = new int[columnas][filas];

        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                transpuesta[j][i] = array[i][j];
            }
        }

        return transpuesta;
    }

    public static void mostrarValores(int[][] array) {
        System.out.println("-------------Valores del array---------------");
        for (int[] fila : array) {
            for (int valor : fila) {
                System.out.print(valor + "\t");
            }
            System.out.println();
        }
    }
}

