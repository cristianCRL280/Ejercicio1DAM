/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ArraysBidimensionales;

/**
 *
 * @author dev
 */
public class InvertirElementosArrayBidimensional {
    public static void main(String[] args) {
        int[][] array = {
            {1, 2, 3},
            {4, 5, 6},
            {7, 8, 9}
        };

        System.out.println("Array original:");
        mostrarValores(array);

        invertirElementos(array);

        System.out.println("Array con elementos invertidos:");
        mostrarValores(array);
    }

    public static void invertirElementos(int[][] array) {
        for (int i = 0; i < array.length; i++) {
            int inicio = 0;
            int fin = array[i].length - 1;

            while (inicio < fin) {
                // Intercambiar los elementos en las posiciones inicio y fin
                int temp = array[i][inicio];
                array[i][inicio] = array[i][fin];
                array[i][fin] = temp;

                inicio++;
                fin--;
            }
        }
    }

    public static void mostrarValores(int[][] array) {
        for (int[] fila : array) {
            for (int valor : fila) {
                System.out.print(valor + "\t");
            }
            System.out.println();
        }
        System.out.println();
    }
}
