/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ArraysBidimensionales;

import java.util.Scanner;

//
//2.- Genera un array de enteros de dos dimensiones (pide las dimensiones al usuario) y posteriormente.
//2.1.- Genera un método que asigne a todas las posiciones de un array bidimensional  que le llegará como parámetro, 
//un valor entero que le llegará como parámetro.
//Modifica el método main para que el array generado anteriormente cargue con datos a través de este método.
//2.2.- Genera un método que imprima por pantalla todos los valores de un array bidimensional que se le pase como parámetro. 
//Imprime por pantalla en forma de filas y columnas usando \t para separar valores.
//Modifica el método main para que imprima por pantalla los valores del array generado anteriormente a través de este método.
//2.3.- Genera un método que asigne valores aleatorios (entre 0 y 9) a todas las posiciones de un array bidimensional que le llegará como parámetro.
//Modifica el método main para que el array generado anteriormente se rellene mediante este método y 
//posteriormente imprime su contenido por pantalla mediante el método del apartado 2.2.
//2.4.- Genera un método al que le llegue como parámetro un array bidimensional y que devuelva la suma de todos sus valores.
//Modifica el método main para que se llame a este método pasando el array generado anteriormente e imprime por pantalla el valor de la suma de sus valores.
//2.5.- Genera un método al que le llegue como parámetro un array bidimensional y que devuelva un array de enteros de una dimensión 
//con el número de filas del array que reciba que contendrá la suma la de los enteros por filas del array original.
//Modifica el método main para que se llame a este método y para que imprima los valores del array resultante.
//2.6.- Genera un método al que le llegue como parámetro un array bidimensional y que devuelva un array de enteros de una dimensión 
//con el número de columnas del array que reciba que contendrá la suma de los enteros por columnas del array original.
//Modifica el método main para que se llame a este método y para que imprima los valores del array resultante.
/**
 *
 * @author dev
 */
public class EjercicioArrayBidimensional2 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int filas, columnas;

        System.out.print("Dame numero de filas: ");
        filas = sc.nextInt();

        System.out.print("Dame numero de columnas: ");
        columnas = sc.nextInt();
        int[][] a = new int[filas][columnas];
        mostrarValores(a);
        asignarValor(a, 5);
        mostrarValores(a);
        asignarValorAleatorio(a);
        mostrarValores(a);
        System.out.println("---------Suma de valores-------------");
        System.out.println("La suma de sus valores es " + sumaValores(a));
        System.out.println("------------------ Suma de filas ---------------------");
        int []sumaFilas = sumaFilas(a);
        for (int i = 0; i < sumaFilas.length; i++) {
            System.out.println("El array en la fila " + i + " suma : " + sumaFilas[i]);
            
        }
         System.out.println("------------------ Suma de columnas ---------------------");
        int []sumaColumnas = sumaColumnas(a);
        for (int i = 0; i < sumaFilas.length; i++) {
            System.out.println("El array en la columna " + i + " suma : " + sumaColumnas[i]);
            
        }
    
    }

    public static void asignarValor(int[][] a, int valor) {

        for (int i = 0; i < a.length; i++) {

            for (int j = 0; j < a[i].length; j++) {

                a[i][j] = valor;

            }

        }

    }

    public static void asignarValorAleatorio(int[][] a) {

        for (int i = 0; i < a.length; i++) {

            for (int j = 0; j < a[i].length; j++) {

                a[i][j] = aleatorio(0, 9);

            }

        }

    }

    public static int sumaValores(int[][] array) {
        int r = 0;

        for (int i = 0; i < array.length; i++) {
            for (int j = 0; j < array[i].length; j++) {

                r += array[i][j];

            }

        }

        return r;

    }
    
    public static int[] sumaColumnas(int[][] a){
        
        int[] r = new int[a[0].length];
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[i].length; j++) {
                
                r[j] += a[i][j];
                
            }
        }
        return r;
        
        
        
        
    }
                public static int[] sumaFilas(int[][] a) {
                    int[] r = new int[a.length];
                    for (int i = 0; i < a.length; i++) {
                       

                        for (int j = 0; j < a[i].length; j++) {
                            
                            r[i] += a[i][j];
                              
                        }
                    }
        return r;
                  
    

    }
    

    public static void mostrarValores(int[][] array) {
        System.out.println("-------------Valores del array---------------");
        for (int i = 0; i < array.length; i++) {
            for (int j = 0; j < array[i].length; j++) {
                System.out.print(array[i][j] + "\t");

            }
            System.out.println();
        }

    }

    public static int aleatorio(int min, int max) {

        return (int) (Math.random() * (max - min + 1) + min);

    }

}
