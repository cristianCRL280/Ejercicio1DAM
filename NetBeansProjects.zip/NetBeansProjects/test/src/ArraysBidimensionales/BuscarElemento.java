/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ArraysBidimensionales;

/**
 *
 * @author dev
 */
import java.util.Scanner;

public class BuscarElemento {
    public static void main(String[] args) {
        int[][] matriz = {
            {1, 2, 3, 4},
            {5, 6, 7, 8},
            {9, 10, 11, 12},
            {13, 14, 15, 16}
        };

        Scanner sc = new Scanner(System.in);
        System.out.println("Introduce el número a buscar: ");
        int numero = sc.nextInt();

        int[] posicion = buscarNumero(matriz, numero);
        if (posicion[0] != -1) {
            System.out.println("Número encontrado en la posición: (" + posicion[0] + ", " + posicion[1] + ")");
        } else {
            System.out.println("Número no encontrado en la matriz.");
        }
    }

    public static int[] buscarNumero(int[][] array, int numero) {
        for (int i = 0; i < array.length; i++) {
            for (int j = 0; j < array[i].length; j++) {
                if (array[i][j] == numero) {
                    return new int[]{i, j}; // Retorna la posición como un array
                }
            }
        }
        return new int[]{-1, -1}; // Retorna -1, -1 si el número no se encuentra
    }
}
