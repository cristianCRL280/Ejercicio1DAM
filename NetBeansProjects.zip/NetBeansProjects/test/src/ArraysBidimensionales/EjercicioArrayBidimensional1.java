/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejemplos;

import java.util.Scanner;



//1.- Realiza un programa que realice las siguientes acciones:
//Pida al usuario un número y lo guarde en una variable n. El usuario introducirá un número entero positivo (no hace falta que lo compruebes)
//Genere un array bidimensional de char, de dimensiones n x n, y que posteriormente rellene la diagonal principal con el carácter ‘A’ y el resto con el carácter ‘*’.
//Imprima por pantalla a través de un método al que le llegará como parámetro el array generado anteriormente, el contenido del array en filas y columnas.
//Repite estas acciones mientras el usuario introduzca un número mayor que cero.
//Ejemplo:
//Introduzca un número: 5
//A  *  *  *  *
//*  A  *  *  *
//*  *  A  *  *
//*  *  *  A  *
//*  *  *  *  A
//
//Introduzca un número: 0
//Adiós!!!
/**
 *
 * @author dev
 */
public class EjercicioArrayBidimensional1 {
    public static void main(String[] args) {
          Scanner sc = new Scanner(System.in);
        int n;
        
        char[][] a;
        
        do {
            System.out.println("Introduzca un numero: ");
            n = sc.nextInt();
            if (n > 0) {
                a = new char[n][n];
                rellenarArray(a);
                mostrarArray(a);
                
            }
            
        } while (n > 0);
        System.out.println("adios");

          
        
    }
    
    public static void rellenarArray(char[][] a){
        
        for (int fila = 0; fila < a.length; fila++) {
            
            for (int columna = 0; columna < a[fila].length; columna++) {
                a[fila][columna] = '*';
                
                if(fila == columna){
                    
                    a[fila][columna] = 'A';
                    
                } else {
                    
                   a[fila][columna] = '*';
                }
                
            }
            
        }
        
    }
    
    public static void mostrarArray(char[][] a){
        
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[i].length; j++) {
                System.out.print(a[i][j] + " ");
                
            }
            System.out.println();
        }
    }
    
}
