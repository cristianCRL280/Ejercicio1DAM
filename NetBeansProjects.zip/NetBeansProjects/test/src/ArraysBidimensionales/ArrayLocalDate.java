/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ArraysBidimensionales;

/**
 *
 * @author dev
 */
import java.time.LocalDate;

public class ArrayLocalDate {
    public static void main(String[] args) {
        // Definir un array de LocalDate con capacidad para 5 fechas
        LocalDate[] fechas = new LocalDate[5];

        // Llenar el array con algunas fechas
        fechas[0] = LocalDate.of(2023, 8, 15);
        fechas[1] = LocalDate.of(2023, 10, 1);
        fechas[2] = LocalDate.of(2024, 1, 1);
        fechas[3] = LocalDate.of(2024, 5, 20);
        fechas[4] = LocalDate.of(2024, 12, 25);

        // Mostrar las fechas del array
        System.out.println("Fechas en el array:");
        for (LocalDate fecha : fechas) {
            System.out.println(fecha);
        }

        // Calcular la diferencia de días entre la primera y última fecha
        long diasEntreFechas = calcularDiferenciaDias(fechas[0], fechas[fechas.length - 1]);
        System.out.println("\nDías entre la primera y última fecha: " + diasEntreFechas);
    }

    // Método para calcular la diferencia de días entre dos LocalDate
    public static long calcularDiferenciaDias(LocalDate fechaInicio, LocalDate fechaFin) {
        return fechaInicio.until(fechaFin).getDays();
    }
}

