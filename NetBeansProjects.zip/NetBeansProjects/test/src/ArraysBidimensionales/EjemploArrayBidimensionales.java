/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ArraysBidimensionales;

/**
 *
 * @author dev
 */
public class EjemploArrayBidimensionales {

    public static void main(String[] args) {
        int[] a1 = new int[5];  //inicializados a 0
        int[] a2 = {1, 4, 5, 7, 2};

        int[][] b1 = new int[3][4];
        int[][] b2 = {
            {1, 4, 4, 4},
            {1, 4, 4},
            {1, 4, 4, 4}
        };
        b2[2][3] = 8; // acctualizo el numero de la fila 2 y de la columna 3 a 8
        System.out.println("array b2 - posicion fila 2 -columna 3: " + b2[2][3]);

//        int[][][] multidimension = new int[2][3][4];

        
        //este for muestra las filas y las columnas de un arrray multidimensional
        
        for (int fila = 0; fila < b2.length; fila++) {
            for (int columna = 0; columna < b2[fila].length; columna++) {
                System.out.println("Voy por la fila: " + fila + " y la columna " + columna);

                System.out.println("------>>>>> y el valor es: " + b2[fila][columna]);

            }

        }

        System.out.println("------------------------");

        
        //este for muestra el contenido del array uno debajo de otro
        for (int fila = 0; fila < b2.length; fila++) {
            for (int columna = 0; columna < b2[fila].length; columna++) {

                System.out.println(b2[fila][columna] + "\t");

            }

            System.out.println();
        }

    }

}
