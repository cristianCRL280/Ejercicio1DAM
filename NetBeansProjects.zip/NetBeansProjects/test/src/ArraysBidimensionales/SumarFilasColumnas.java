/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ArraysBidimensionales;

/**
 *
 * @author dev
 */
public class SumarFilasColumnas {
    public static void main(String[] args) {
        int n = 4; // Tamaño de la matriz
        int[][] matriz = {
            {1, 2, 3, 4},
            {5, 6, 7, 8},
            {9, 10, 11, 12},
            {13, 14, 15, 16}
        };

        mostrarValores(matriz);
        sumarFilas(matriz);
        sumarColumnas(matriz);
    }

    public static void mostrarValores(int[][] array) {
        System.out.println("-------------Valores del array---------------");
        for (int i = 0; i < array.length; i++) {
            for (int j = 0; j < array[i].length; j++) {
                System.out.print(array[i][j] + "\t");
            }
            System.out.println();
        }
    }

    public static void sumarFilas(int[][] array) {
        for (int i = 0; i < array.length; i++) {
            int suma = 0;
            for (int j = 0; j < array[i].length; j++) {
                suma += array[i][j];
            }
            System.out.println("Suma de la fila " + i + ": " + suma);
        }
    }

    public static void sumarColumnas(int[][] array) {
        for (int j = 0; j < array[0].length; j++) {
            int suma = 0;
            for (int i = 0; i < array.length; i++) {
                suma += array[i][j];
            }
            System.out.println("Suma de la columna " + j + ": " + suma);
        }
    }
}

