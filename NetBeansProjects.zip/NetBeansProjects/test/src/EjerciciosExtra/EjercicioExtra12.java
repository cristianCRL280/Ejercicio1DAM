/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package EjerciciosExtra;

//Pide una cadena de texto al usuario y muestra la suma de los números que contenga esa cadena de texto.

import java.util.Scanner;

//Repite esta acción hasta que el usuario introduzca la palabra fin.
//Finalmente muestra la cadena de texto cuya suma de números sea mayor.
//
//Ejemplo:
//Introduce un texto: Hol4 qu3 t4l
//Salida: 11
//Introduce un texto: muy b13n
//Salida: 4
//Introduce un texto: 44aa33
//Salida: 14
//Introduce un texto: fin
//La cadena de texto con una suma mayor es: 44aa33


/**
 *
 * @author dev
 */
public class EjercicioExtra12 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        String txt, txtMejor = "";
        int max = Integer.MIN_VALUE;
        
        do{
            System.out.println("Introduzca un texto: ");
            txt = sc.nextLine();
            if (!txt.equalsIgnoreCase("fin")) {
                System.out.println("Salida " + sumaNumerosTxt(txt));
                if (sumaNumerosTxt(txt) > max) {
                    max = sumaNumerosTxt(txt);
                    txtMejor = txt;
                    
                }
            }
            
            
        } while(!txt.equalsIgnoreCase("fin"));
        System.out.println("El texto con mayor suma : "  + txtMejor);
        
    }
    
    
    public static int sumaNumerosTxt(String txt){
        int r = 0;
        for (int i = 0; i < txt.length(); i++) {
            
            if (Character.isDigit(txt.charAt(i))) {
                r += Character.getNumericValue(txt.charAt(i));
                
            }
            
        }
        
        return r;
    }
    
}
