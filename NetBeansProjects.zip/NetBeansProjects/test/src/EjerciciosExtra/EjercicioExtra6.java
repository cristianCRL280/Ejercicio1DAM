/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicios;
//6.- Escribe un programa que visualice un triángulo isósceles de 10 filas, como se muestra a continuación, utilizando bucles: 
//(hay 10 filas. En la fila 1 hay 1 asterisco, en la fila 2 hay 2 asteriscos... en la fila 9 hay 9 asteriscos... en la fila 10 hay 10 asteriscos)

import java.util.Scanner;

//*
//**
//***
//****
//*****
//******
//*******
//********
//*********
//********** 
/**
 *
 * @author dev
 */
public class EjercicioExtra6 {
    public static void main(String[] args) {
     
       
        
        for (int i = 1; i <= 10; i++) {
            
            for (int j = 0; j < i; j++) {
                
             
                System.out.print("*");
            }
            System.out.println("*");
             
        }
        
        
    }
}
