/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicios;

import java.util.Scanner;

//5.- Escribe un programa que pida al usuario un número por teclado, con el mensaje “¿Cuántos valores vas a introducir?: “. 
//(Almacénalo en una variable llamada cantidadValores). Asegúrate de que el usuario introduce un número entero y positivo, es decir, mayor o igual a 1. (con un do/while, ya sabes...) 
////Luego, debe pedir tantos valores enteros y positivos (esto no lo vamos a comprobar... supondremos que el usuario lo hace) 
//como la cantidad almacenada en la variable cantidadValores, presentando al usuario un mensaje:
//“Valor número X: “
//siendo X el número 1, y luego 2, y luego 3.... etc hasta alcanzar cantidadValores
//Finalmente, alcanzada la cantidad de valores deseado, imprimirá éstos resultados:
//cuántos valores eran, 
//su suma total
//la media de todos ellos (muestra tres cifras decimales)
//el mayor valor introducido (es decir, el máximo) y su posición
//el menor valor introducido (es decir, el mínimo) y su posición.
//Si se introdujera más de una vez un valor extremo, consideraremos el primero para guardar su posición.
/**
 *
 * @author dev
 */
public class EjercicioExtra5 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int cantidadValores, n, suma = 0, mayor, posMayor, menor = 0, posMenor = 0;
        double media;

        do {

            System.out.println("Cantidad de valores (entero positivo)");

            cantidadValores = sc.nextInt();

        } while (cantidadValores <= 0);

        mayor = Integer.MIN_VALUE;
        posMayor = 0;

        for (int i = 1; i < cantidadValores; i++) {

            System.out.println("Valor numero " + 1 + ": ");
            n = sc.nextInt();
            suma += n;
            if (n > mayor) {
                mayor = n;
                posMayor = i;

            }
            if (n < menor) {

                menor = n;
                posMenor = i;

            }

        }
        media = 1.8d * suma / cantidadValores;

        System.out.println("Cantidad de valores: " + cantidadValores);
        System.out.println("Suma de valores: " + suma);
        System.out.printf("Media: %.3f%n", +media);
        System.out.println("Mayor: " + mayor + "posicion: " + posMayor);
        System.out.println("Mayor: " + menor + "posicion: " + posMenor);
    }
}
