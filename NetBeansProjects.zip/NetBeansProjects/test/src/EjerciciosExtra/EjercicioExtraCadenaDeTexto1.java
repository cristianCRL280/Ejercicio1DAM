/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicios;

import java.util.Scanner;

/**
 *
 * @author dev
 */
public class EjercicioExtraCadenaDeTexto1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        String tecla, texto;
        int r;
        
        do {
            tecla = sc.next();
            texto = sc.next();
            
            if (!(tecla.equals("0") && texto.equals("0"))) {
                
                r = convertir(tecla,texto);
                System.out.println("Salida: " + r);
                
                
                
            }
            
        } while (!(tecla.equals("0") && texto.equals("0")));
    }
    
    
    public static int convertir(String tecla, String texto){
        
        int r = 0;
        texto = texto.replaceAll(tecla, "");
        
        if(texto.equals("")){
            r = 0;
        } else {
            
        
        r = Integer.parseInt(texto);
        return r;
        }
        return r;
    }
}
