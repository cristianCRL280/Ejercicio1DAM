/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicios;

//3.- Escribe un programa que pida al usuario un número entero de tres dígitos.
import java.util.Scanner;

//(Supondremos que el usuario se comporta correctamente e introduce un número entre el 0 y el 999)
//El programa imprimirá otro número que tenga las mismas cifras, pero en orden inverso:
//Ej: Si el usuario introduce 128, se escribirá 821.
//Programaremos un método con la siguiente signatura:
//public static int obtenerNumeroInvertido(int numero) 
//Para invertir un número realizamos cocientes y  restos enteros sobre la cifra.
//Por ejemplo, sobre el número 128
//128%10 es 8
//128/10 es 12
/**
 *
 * @author dev
 */
public class EjercicioExtra3 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int numero, resultado;

        System.out.println("Dame un numero de 3 digitos");

        numero = sc.nextInt();

        resultado = obtenerNumeroInvertido(numero);

        System.out.println(resultado);

    }

    public static int obtenerNumeroInvertido(int numero) {

        int resultado = 0;
        int unidades = numero % 10;
        int aux = numero / 10;
        int decenas = aux % 10;
        int centenas = aux / 10;
        resultado = unidades * 100 + decenas * 10 + centenas;
        return resultado;

    }
}
