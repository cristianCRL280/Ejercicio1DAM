/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicios;

import java.util.Scanner;

//Escribe un programa que pida al usuario un número “n” entero positivo y que escriba por pantalla la serie fibonacci hasta la iteracción “n”. Repite esta acción hasta que el número introducido por el usuario sea menor o igual a 2. Ejemplo:
//
//Introduce un número n: 5
//Salida: 1 1 2 3 5
//Introduce un número n: 6
//Salida : 1 1 2 3 5 8
//Introduce un número n: 0
//Adiós!!!
//
//Usa un método fibonnaci que reciba como parámetro el número n y devuelva un String con la salida
/**
 *
 * @author dev
 */
public class EjercicioFibonacci {

    public static void main(String[] args) {
        int n;

        Scanner sc = new Scanner(System.in);

        do {
            System.out.println("Introduzca un numero: ");
            
            n = sc.nextInt();
            
            if (n > 2) {
                System.out.println("Salidas " + fibonacci(n));
                
                
                
            }

        } while(n > 2);
        
        System.out.println("Adios");

    }
    
    public static String fibonacci( int n) {
        
        String r = "";
        
        int a = 1, b =1, c;
        r = "1 1";
        
        for (int i = 2; i <= n; i++) {
            
            c = a + b;
            r = r + " " + c;
            a = b;
            b = c;
        }
        return r;
    }

}
