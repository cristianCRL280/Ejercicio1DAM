
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
//8.- Escribe un programa que lea un mes en número (1 para enero, 2 para febrero, etc) y un año y que imprima por pantalla el número de días de ese mes. OJO: 
//un año es bisiesto si es divisible por cuatro, excepto cuando es divisible por 100, a no ser que sea divisible por 400.
//Así, 1900 no fue bisiesto, pero el año 2000 si lo fue.
/**
 *
 * @author dev
 */
public class EjercicioExtra7 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int i, ano, r;

        System.out.println("Dame un numero del 1 al 12");

        i = sc.nextInt();

        System.out.println("Dame un año");

        ano = sc.nextInt();

        if (i == 1) {

            System.out.println("Enero y tiene 31 dias");

        }
        if (i == 2) {

            if (ano % 4 != 0) {

                r = 28;
                System.out.println("Febrero y tiene 28 dias");
            } else {
                r = 29;

                if (ano % 100 == 0) {
                    r = 28;

                    if (ano % 400 == 0) {

                        r = 30;

                        System.out.println("Es año bisiesto y tiene: " + r);
                    }

                }

            }

        }
        if (i == 3) {

            System.out.println("Marzo y tiene 31 dias");

        }
        if (i == 4) {

            System.out.println("Abril y tiene 30 dias");

        }
        if (i == 5) {

            System.out.println("Mayo y tiene 31 dias");

        }
        if (i == 6) {

            System.out.println("Junio y tiene 30 dias");

        }
        if (i == 7) {

            System.out.println("Julio y tiene 31 dias");

        }
        if (i == 8) {

            System.out.println("Agosto y tiene 31 dias");

        }
        if (i == 1) {

            System.out.println("Septiembre y tiene 31 dias");

        }
        if (i == 10) {

            System.out.println("Octubre y tiene 30 dias");

        }
        if (i == 11) {

            System.out.println("Noviembre y tiene 31 dias");

        }
        if (i == 12) {

            System.out.println("Diciembre y tiene 31 dias");

        }

    }
}
