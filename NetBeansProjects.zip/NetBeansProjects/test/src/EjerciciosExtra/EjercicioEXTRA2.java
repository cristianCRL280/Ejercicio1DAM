/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicios;

import java.util.Scanner;
//2.- Repostando 30€ de gasolina, mi coche recorre 410 kilómetros. El litro de gasolina estaba a 1.30 euros.... Me pregunto ¿Cuántos litros de gasolina
//gastará mi coche a los 100 Km?
//Programémoslo.
//Haz un programa que pida al usuario:
//El dinero que repostó la última vez (en euros)
//Cuántos kilómetros recorrió su coche con ese dinero.
//El precio de un litro de carburante
//Y que calcule y le informe de:
//Cuántos litros gasta su coche cada 100 Km.
//La relaciones son lineales, pueden resolverse mediante reglas de tres.
//Utiliza dos métodos de cálculo y un método principal de instancia
//public static double obtenerLitrosPorCien(double kilometrosTotales, double litrosTotales)
//public static double obternerLitrosDeImporte(double importeTotal, double precioPorLitro)
//public static void main (String[] args)

/**
 *
 * @author dev
 */
public class EjercicioEXTRA2 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        double dinero, kilometrosRecorridos, pCarburante, resultado;
        System.out.println("Cuanto dinero repostastes la ultima vez: ");

        dinero = sc.nextDouble();
        System.out.println("Cuantos kilometros recorristes? ");

        kilometrosRecorridos = sc.nextDouble();

         System.out.println("Precio del litro de carburante:  ");

       pCarburante = sc.nextDouble();
       
        
       resultado = obtenerLitrosPorCien (kilometrosRecorridos, obternerLitrosDeImporte(dinero, pCarburante));
       
        System.out.println("Tu coche gasta a los cien: " + resultado);
    }
    
    
    
    
    public static double obtenerLitrosPorCien(double kilometrosTotales, double litrosTotales){
        
     return litrosTotales * 100 / kilometrosTotales; 
      
        
    }
    
    public static double obternerLitrosDeImporte(double importeTotal, double precioPorLitro){
        
        
        return importeTotal / precioPorLitro;
        
        
    }
}
