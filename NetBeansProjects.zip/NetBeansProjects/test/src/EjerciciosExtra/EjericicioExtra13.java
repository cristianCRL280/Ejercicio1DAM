/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package EjerciciosExtra;

import java.util.Scanner;

/**
 *
 * @author dev
 */
public class EjericicioExtra13 {
    public static void main(String[] args) {
        
       Scanner sc = new Scanner(System.in);
        System.out.println("Introduce un numero n: ");
        int n = sc.nextInt();
        System.out.println("Introduce un numero de inicio: ");
        int inicio = sc.nextInt();
        int [] a = serie(n,inicio);
        
        System.out.println("salida");
        for (int valor : a) {
            System.out.println(" " + valor );
            
            
        }
        System.out.println();
        
    }
    
    public static int[] serie (int n, int inicio){
        int[] a = new int[n];
        for (int i = 0; i < a.length; i++) {
            a[i] = inicio * (i + 1);
        }
        
        return a;
        
    }
    
}
