/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package EjerciciosExtra;

//Realizar un programa java que pida al usuario una palabra. Tras introducir esta palabra el programa deberá indicar, si esta palabra es palíndroma o no.
import static Ejercicios.EjercicioExtraCadenaDeTexto2.convertir;
import java.util.Scanner;

//Palíndromo: Palabra que es igual si se lee de izquierda a derecha que de derecha a izquierda.
//Repite esta acción hasta que el usuario introduzca la palabra “fin”.
//No se pueden usar las clases StringBuilder o StringBuffer.
//Ejemplo:
//Introduce una palabra: oso
//Si es palíndromo
//Introduce una palabra: perro
//No es palíndromo
//Introduce una palabra: fin
//Adios!!!
/**
 *
 * @author dev
 */
import java.util.Scanner;

public class Palindromo {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduce un número: ");
        int numero = sc.nextInt();

        if (esPalindromo(numero)) {
            System.out.println("El número " + numero + " es un palíndromo.");
        } else {
            System.out.println("El número " + numero + " no es un palíndromo.");
        }
    }

    public static boolean esPalindromo(int numero) {
        String strNumero = String.valueOf(numero);
        int longitud = strNumero.length();
        for (int i = 0; i < longitud / 2; i++) {
            if (strNumero.charAt(i) != strNumero.charAt(longitud - 1 - i)) {
                return false;
            }
        }
        return true;
    }
}

