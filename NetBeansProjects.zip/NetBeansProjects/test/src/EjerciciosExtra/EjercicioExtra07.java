/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicios;
//7.- Escribe un programa que visualice una figura como ésta, utilizando una técnica similar a la del ejercicio anterior:  
//@
//@@
//@@@
//@@@@
//@@@@@
//####
//###
//##
//#
/**
 *
 * @author dev
 */
public class EjercicioExtra07 {
     public static void main(String[] args) {
     
       
        
        for (int i = 1; i <= 5; i++) {
            
            for (int j = 0; j < i; j++) {
                
             
                System.out.print("@");
            }
            System.out.println();
            
            
            
                  
        }
          for (int i = 4; i > 1; i--) {
             
             
             for (int j = 0; j < i; j++) {
                 
                 System.out.print("#");
                 
             }
             System.out.println();
         } 
      
        
    }
}
