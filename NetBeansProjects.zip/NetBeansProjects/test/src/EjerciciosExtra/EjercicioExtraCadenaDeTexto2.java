/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicios;

import java.util.Scanner;

/**
 *
 * @author dev
 */
public class EjercicioExtraCadenaDeTexto2 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        String texto;

        do {
            System.out.println("Introduzca un texto: ");

            texto = sc.nextLine();
            if (!texto.equals("fin")) {

                System.out.println("Salida: " + convertir(texto));

            }

        } while (!texto.equals("fin"));
    }

    public static String convertir(String entrada) {

        String salida = "";
        String flag = "M";

        for (int i = 0; i < entrada.length(); i++) {
            if (entrada.charAt(i) != ' ') {

                if (flag.equals("M")) {

                    salida += Character.toUpperCase(entrada.charAt(i));

                    flag = "m";

                } else {
                    salida += Character.toLowerCase(entrada.charAt(i));

                    flag = "M";
                }

            } else {

                salida += ' ';
            }

        }

        return salida;
    }

}
