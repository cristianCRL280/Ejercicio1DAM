/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package EjerciciosExtra;
//
//Realiza un programa que pida al usuario un número.
//Posteriormente el programa pedirá al usuario tantas cadenas de texto como el número introducido anteriormente.
//Respecto a esas cadenas de texto, el programa deberá mostrar:
//- La cadena de texto con más vocales
//- La cadena de texto con menos vocales
//- La cadena de texto más larga
//- La cadena de texto más corta
//- La media de las longitudes de las cadenas de texto
//Repite estas acciones mientras el número introducido por el usuario sea distinto de cero.

import java.util.Scanner;

public class EjercicioExtra11 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n;

        do {
            System.out.println("Cuantas veces lo quieres hacer");
            n = sc.nextInt();
            sc.nextLine();
            if (n != 0) {
                tratarCaso(n, sc);
            }
        } while (n != 0);
        System.out.println("Adiooos");
    }

    public static void tratarCaso(int n, Scanner sc) {
        String txt, txtMasVocales = "", txtMenosVocales = "", txtLarga = "", txtCorta = "";
        int masVocales = Integer.MIN_VALUE,
                menosVocales = Integer.MAX_VALUE,
                max = Integer.MIN_VALUE,
                min = Integer.MAX_VALUE,
                suma = 0;
        double media;

        for (int i = 0; i < n; i++) {
            System.out.println("Introduce una palabra");
            txt = sc.nextLine();
            suma += txt.length();
            if (txt.length() > max) {
                max = txt.length();
                txtLarga = txt;
            }
            if (txt.length() < min) {
                min = txt.length();
                txtCorta = txt;
            }
            if (numVocales(txt) > masVocales) {
                masVocales = numVocales(txt);
                txtMasVocales = txt;
            }
            if (numVocales(txt) < menosVocales) {
                menosVocales = numVocales(txt);
                txtMenosVocales = txt;
            }
        }
        media = 1.0d * suma / n;
        System.out.println("La cadena de texto con mas vocales: " + txtMasVocales);
        System.out.println("La cadena de texto con menos vocales: " + txtMenosVocales);
        System.out.println("La cadena de texto con mas vocales mas larga: " + txtLarga);
        System.out.println("La cadena de texto  mas corta: " + txtCorta);
        System.out.println("La media de las longitudes es " + media);
    }

    public static int numVocales(String txt) {
        int r = 0;
        txt = txt.toUpperCase();
        for (int i = 0; i < txt.length(); i++) {
            if (txt.charAt(i) == 'A' || txt.charAt(i) == 'E' || txt.charAt(i) == 'I' || txt.charAt(i) == 'O' || txt.charAt(i) == 'U') {
                r++;
            }
        }
        return r;
    }
}