/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicios;

import java.util.Scanner;

//
//Aquí os dejo el enunciado
////Escribe un programa que pida al usuario un número entero de inicio y otro de fin. 
//Este programa debe escribir los números primos que hay desde ese número de inicio hasta ese número de fin.
//El programa debe repetir la acción hasta que el número de fin sea mayor o igual al número de inicio. Ejemplo
//
//Inicio: 4
//Fin: 9
//Primos: 5 7
//
//Inicio: 3
//Fin: 6
//Primos: 3 5
//
//Inicio: 3
//Fin: 2
//Adiós!!!
//
//Usa un método llamado esPrimo que reciba un número entero como parámetro y devuelva un boolean indicando si es o no primo.
/**
 *
 * @author dev
 */
public class EjercicioExtraNumerosPrimos {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int Inicio, Fin;

        do {

            System.out.println("Dame un numero de inicio");

            Inicio = sc.nextInt();

            System.out.println("Dame un numero de final");

            Fin = sc.nextInt();

            if (Inicio < Fin) {

                System.out.print("Primos: ");

                for (int i = Inicio; i <= Fin; i++) {

                    if (esPrimo(i)) {

                        System.out.println(i + " ");

                    }

                }

            }

        } while (Inicio < Fin);

        System.out.println("Adios!!");

    }

    public static boolean esPrimo(int n) {

        for (int i = 2; i < n; i++) {

            if (n % i == 0) {

                return false;

            }

        }

        return true;
    }

}
