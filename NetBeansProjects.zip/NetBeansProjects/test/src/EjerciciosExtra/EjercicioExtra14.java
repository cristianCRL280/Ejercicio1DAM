/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package EjerciciosExtra;

//Pide dos números enteros al usuario.

import java.util.Scanner;

//Divide el número mayor entre el menor, y guarda en el resultado como número mayor.
//Muestra el número de veces que se pueda realizar esta operación hasta que el número mayor sea menor que el mayor.
//
//Si los números introducidos fueran 9 y 3 la operación se podría realizar 2 veces
//9 / 3 = 3 
//3 / 3 = 1 - en este punto 1 es ya menor que 3 así que paramos.
//**
// *
// * @author dev
// */
public class EjercicioExtra14 {
    public static void main(String[] args) {
           Scanner sc = new Scanner(System.in);
        int mayor = 0, menor = 0, resultado = 0, cont = 0;
        System.out.println("Introduce un numero n: ");
        int n2 = sc.nextInt();
        System.out.println("Introduce un numero n: ");
        int n1 = sc.nextInt();
       
        if (n2 > n1) {
            mayor = n2;
            menor = n1;
            
        }
        if (n1 > n2) {
            
            mayor = n1;
            menor = n2;
            
        }
        
        
           do {
               mayor = mayor / menor;
               cont++;
           
            
        } while (mayor >= menor);
           
           System.out.println("el resultado es: " + mayor +  " y se ha hecho " + cont + " veces");
            
       
    
    }   
}
