/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicios;

import java.util.Scanner;

//
////4.- El Grand prix de patinaje artístico por parejas está siendo retransmitido por la cadena Tele7.
////Cada pareja realiza tres pruebas, que los jueces puntúan de 0 a 10 con decimales.
////Las parejas realizan la primera prueba un día, la segunda al siguiente y la tercera al tercer día. Este tercer día es el más emocionante porque la puntuación final 
//es el promedio de las tres pruebas de cada pareja, y a medida que van realizando la tercera prueba se va alterando el palmarés.
////Para retransmitir la tercera prueba con más datos, los comentaristas de Tele7 han pedido un programa que calcule la puntuación que necesita una pareja para igualar 
//a la pareja ganadora.
////Los comentaristas pretenden utilizar el programa a partir de la segunda pareja que participe en ese tercer día, para ir diciendo a los espectadores qué puntuación 
//deben obtener ese día para ganar.
//Haz un programa que pida por teclado:
//La puntuación promedio de la pareja que va ganando
//La puntuación del primer día de la pareja que va a salir
//La puntuación del segundo día de la pareja que va a salir
//Y que calcule e imprima
//La puntuación que necesita la pareja que va a salir en el tercer día para igualar a la pareja que va ganando 
/**
 *
 * @author dev
 */
public class EjercicioExtra4 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        double a, b, c, puntuacionTotal, resultado;
        
        
        System.out.println("Puntuacion de la pareja que va ganando es: ");
        a = sc.nextDouble();

        System.out.println("Puntuacion del primer dia de la pareja que va a salir es: ");

        b = sc.nextDouble(); 

          System.out.println("Puntuacion del segundo dia de la pareja que va a salir es: ");

        c = sc.nextDouble(); 
        
        puntuacionTotal = necesitaPuntuacion(b, c);
        
        resultado = a - puntuacionTotal;
        
        System.out.println("Su puntuacion actual es de: " + puntuacionTotal);
        
        System.out.println("La pareja necesita: " + resultado + " puntos para ganar");

    }
 public static double necesitaPuntuacion(double n1,double n2) {

        double resultado;
       
        resultado = n1 + n2;
        return resultado;
        
    }
}
