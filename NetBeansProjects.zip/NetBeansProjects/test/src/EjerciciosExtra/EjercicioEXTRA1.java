/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicios;

import java.util.Scanner;

//
//1.- Escribe un programa que calcule la superficie y el volumen de un cilindro. 
//Escoge tú las unidades, pero que al supuesto usuario del programa le quede bien claro por los mensajes que pongas. Los datos que se pedirán por teclado serán la altura y el radio.
//Si h es la altura y r es el radio, la superficie (s) y el volumen (v) son:
//v = π r² h
//s = 2π r h + 2π r²
//Utiliza dos métodos de cálculo y un método main de instancia.
//public static double obtenerSuperficie(double radio, double altura)
//public static double obtenerVolumen(double radio, double altura)
//public static void main (String[] args)
/**
 *
 * @author dev
 */
public class EjercicioEXTRA1 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        double r, h, resultadoSuperficie, resultadoVolumen;

        System.out.println("Dame el radio en cm: ");

        r = sc.nextDouble();

        System.out.println("Dame la altura en cm: ");

        h = sc.nextDouble();

       resultadoSuperficie = obtenerSuperficie(r, h);
        resultadoVolumen = obtenerVolumen(r, h);
        
        System.out.println("La superficie es: " + resultadoSuperficie + "cm");
        System.out.println("El volumen es: " + resultadoVolumen + "cm");
        
    }

    public static double obtenerSuperficie(double radio, double altura) {

        double superficie;

        superficie = 2 * Math.PI * radio * radio * altura;
        return superficie;

    }

    public static double obtenerVolumen(double radio, double altura) {

        double volumen;

        volumen = 2 * Math.PI * radio * altura + 2 * Math.PI * radio * radio;

        return volumen;

    }

    
    
    
    
}
