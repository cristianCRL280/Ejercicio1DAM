/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicios;

//
import java.util.Scanner;

//
//Escribe un programa que pida al usuario un número “n” entero positivo y que escriba por pantalla el cálculo del factorial de dicho número.
//Introduce un número n: 5
//Salida: 120
//Introduce un número n: 6
//Salida : 720
//Introduce un número n: 0
//Adiós!!!
//
//Usa un método factorial que reciba como parámetro el número n y devuelva un entero con la salida.
//Haz dos versiones de este método: una con un algoritmo que use un bucle for, y otro con un algoritmo recursivo.
/**
 *
 * @author dev
 */
public class EjercicioExtraFactorial {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Dame n: ");

        int n, resultado;

        n = sc.nextInt();
        
        resultado = factorial(n);
        
        System.out.println(resultado);

    }

    
    
    public static int factorial(int numero) {
        
        int resultado = 1;

        for (int i = 2; i <= numero; i++) {
            
            
            
            resultado = resultado * i;
            
            
            
            
            
        }
        return resultado;
    }
}

