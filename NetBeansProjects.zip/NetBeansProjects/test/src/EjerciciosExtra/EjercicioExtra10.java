/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package EjerciciosExtra;

//

import java.util.Scanner;

//Elabora un programa java que realice las siguientes acciones:
////- Pida al usuario que introduzca un dividendo y un divisor. El usuario introducirá números enteros y un dividendo mayor que el divisor 
//(no hace falta que hagas comprobaciones).
//- Pase esos datos a un método que se llame divisionEntera, que debe devolver el resultado de la división entera del dividendo entre el divisor. 
//Para esta operación está prohibido el uso de las operaciones java “/” y “%”, así que tendrás que hacerlo con otras operaciones y haciendo uso de algún bucle. 
//Muestra la salida por pantalla desde el programa principal.
////Pase los datos necesarios a un método que se llame restoDivisionEntera, 
//que debe devolver el resultado del resto de la división entera del dividendo entre el divisor. 
//Para esta operación está prohibido el uso de las operaciones java “/” y “%” y es obligatorio hacer uso del resultado del método del apartado anterior. 
//Muestra la salida por pantalla desde el programa principal.
////Ejemplo:
//Introduzca el dividendo: 31
//Introduzca el divisor: 5
////Resultado: 6
//Resto: 1
/**
 *
 * @author dev
 */
public class EjercicioExtra10 {
    public static void main(String[] args) {
         Scanner sc = new Scanner(System.in);
         int dividendo, divisor, resultadoDivisionEntera, resto;
         
         System.out.println("Dame un dividendo ");
         dividendo = sc.nextInt();
         
         System.out.println("Dame un divisor ");
         divisor = sc.nextInt();
         
       resultadoDivisionEntera = divisionEntera(dividendo,divisor);
        
        System.out.println("El resultado de la division entera es: " + resultadoDivisionEntera);
   resto = restoDivisionEntera(resultadoDivisionEntera, dividendo, divisor);
        System.out.println("El resto: " + resto);
    }
    
    
    
    
    public static int divisionEntera(int dividendo, int divisor){
       
        int contador = 1;
        int multiplicacion;
        
        multiplicacion = contador * divisor;
        while(multiplicacion <= dividendo){
            contador++;
            multiplicacion = contador * divisor;
            
        }
        
        contador--;
        return contador;
                
        
        
        
        
        
        

    }
    
    public static int restoDivisionEntera(int cociente, int dividendo, int divisor){
        
     return dividendo - (cociente * divisor);   
        
    }
           
    
}
