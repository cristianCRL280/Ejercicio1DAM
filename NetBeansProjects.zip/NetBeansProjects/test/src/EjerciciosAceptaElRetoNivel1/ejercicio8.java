/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package EjerciciosAceptaElRetoNivel1;

import java.util.Scanner;

/**
 *
 * @author dev
 */
public class ejercicio8 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int nVeces, SegundosIniciales, h, m, s, resto;

        nVeces = sc.nextInt();

        for (int i = 0; i < nVeces; i++) {

            SegundosIniciales = sc.nextInt();

            h = SegundosIniciales / 3600;
            resto = SegundosIniciales % 3600;
            m = resto / 60;
            s = resto % 60;

            System.out.printf("%02d:%02d:%02d\n",  h, m,s);

        }

    }
}
