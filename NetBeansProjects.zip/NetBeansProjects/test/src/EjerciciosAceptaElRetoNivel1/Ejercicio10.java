/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package EjerciciosAceptaElRetoNivel1;

import java.util.Scanner;

/**
 *
 * @author dev
 */
public class Ejercicio10 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int nVeces, sueldo, gastos, resultado;

        nVeces = sc.nextInt();

        for (int i = 0; i < nVeces; i++) {
            resultado = 0;
            sueldo = sc.nextInt();
            gastos = sc.nextInt();

            resultado = sueldo + gastos;

       

            if (resultado >= 0) {

                System.out.println("SI");

            } else if (resultado < 0) {

                System.out.println("NO");

            }

        }

    }
}
