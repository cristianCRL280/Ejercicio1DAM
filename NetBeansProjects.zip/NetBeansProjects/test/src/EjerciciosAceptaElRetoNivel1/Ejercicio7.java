/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package EjerciciosAceptaElRetoNivel1;

import java.util.Scanner;

/**
 *
 * @author dev
 */
public class Ejercicio7 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
       long num, den;
        long resultado;

        do {
            num = sc.nextInt();
            den = sc.nextInt();

            factorial1(num);
            factorial2(den);

            resultado = factorial1(num) / factorial2(den);
            
            
            System.out.println(resultado);

        } while (num > den);

    }

    public static long factorial1(long numero) {

        long resultado = 1;

        for (long i = 2; i <= numero; i++) {

            resultado = resultado * i;

        }
        return resultado;
    }

    public static long factorial2(long numero) {

        long resultado = 1;

        for (long i = 2; i <= numero; i++) {

            resultado = resultado * i;

        }
        return resultado;
    }
}
