/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package EjerciciosAceptaElRetoNivel1;

import java.util.Scanner;

/**
 *
 * @author dev
 */
public class Ejercicio4 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n;
        String numero = "";
        int r;
        int resultado = 0;
        do {
            n = sc.nextInt();
           
            if (n > 0) {

                numero = Integer.toString(n);

                for (int i = 0; i < numero.length(); i++) {

                    System.out.print(numero.charAt(i));

                    r = Character.getNumericValue(numero.charAt(i));

                    resultado = r + resultado;

                    if (i < numero.length() - 1) {
                        System.out.print(" + ");
                    }

                }

                System.out.println(" = " + resultado);
                 resultado = 0;

            }
        } while (n > 0);

    }
}
