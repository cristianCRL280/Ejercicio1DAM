/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package EjerciciosAceptaElRetoNivel1;

import java.util.Scanner;

/**
 *
 * @author dev
 */
public class Ejercicio11 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n, resultado = 0;
        do {
            n = sc.nextInt();

            if (n != 0) {

                for (int i = n; i > 0; i--) {

                    resultado += i * 3;

                }

                System.out.println(resultado);
                resultado = 0;
            }
        } while (n != 0);

    }

}
