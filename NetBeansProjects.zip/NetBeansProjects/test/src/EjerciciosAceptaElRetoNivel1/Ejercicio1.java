/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package EjerciciosAceptaElRetoNivel1;

import java.util.Scanner;

public class Ejercicio1 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        while (true) {
            int distancia;
            int velocidadMaxima;
            int tiempo;

            distancia = sc.nextInt();
            velocidadMaxima = sc.nextInt();
            tiempo = sc.nextInt();

            if (tiempo < 0 && distancia < 0 && velocidadMaxima < 0) {
                System.out.println("ERROR");
                continue;

            }
            if (distancia == 0 && velocidadMaxima == 0 && tiempo == 0) {
                break;
            }
            double velocidadCoche = (double) distancia / tiempo * 3.6;

            if (velocidadCoche <= velocidadMaxima) {
                System.out.println("OK");

            } else if (velocidadCoche <= velocidadMaxima * 1.2) {
                System.out.println("MULTA");

            } else {

                System.out.println("PUNTOS");
            }

        }
    }
}
