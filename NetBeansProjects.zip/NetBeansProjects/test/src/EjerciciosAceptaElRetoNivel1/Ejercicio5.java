/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package EjerciciosAceptaElRetoNivel1;

import java.util.Scanner;

/**
 *
 * @author dev
 */
public class Ejercicio5 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int altura = 0;
        int anchura = 0;

        for (int i = 0; i < 10; i++) {

            altura = sc.nextInt();
            anchura = sc.nextInt();

            int resultado = (altura + altura) + (anchura + anchura);

            if (altura < 0 || anchura < 0) {
                break;
            }

            System.out.println(resultado);
        }

    }
}
