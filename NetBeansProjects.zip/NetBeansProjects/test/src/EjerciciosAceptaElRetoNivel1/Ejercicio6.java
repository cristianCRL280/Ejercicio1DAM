/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package EjerciciosAceptaElRetoNivel1;

import java.util.Scanner;

/**
 *
 * @author dev
 */
public class Ejercicio6 {

    public static void main(String[] args) {

        int restaDiasDeMes = 0, sumaDiasDeMes = 0, año = 365,
                resultado = 0, numeroCasos = 0;
        Scanner sc = new Scanner(System.in);

        numeroCasos = sc.nextInt();

        for (int i = 0; i < numeroCasos; i++) {

            int dia = sc.nextInt();
            int mes = sc.nextInt();

            switch (mes) {
                case 1:

                    restaDiasDeMes = 31 - dia;
                    sumaDiasDeMes = restaDiasDeMes + 28 + 31 + 30 + 31 + 30 + 31 + 31 + 30 + 31 + 30 + 31;
                    System.out.println(sumaDiasDeMes);
                    break;
                case 2:

                    restaDiasDeMes = 28 - dia;
                    sumaDiasDeMes = restaDiasDeMes + 31 + 31 + 30 + 31 + 30 + 31 + 31 + 30 + 31 + 30 + 31;
                    System.out.println(sumaDiasDeMes);
                    break;
                case 3:

                    restaDiasDeMes = 31 - dia;
                    sumaDiasDeMes = restaDiasDeMes + 30 + 31 + 30 + 31 + 31 + 30 + 31 + 30 + 31;
                    System.out.println(sumaDiasDeMes);
                    break;
                case 4:

                    restaDiasDeMes = 30 - dia;
                    sumaDiasDeMes = restaDiasDeMes + 31 + 30 + 31 + 31 + 30 + 31 + 30 + 31;
                    System.out.println(sumaDiasDeMes);
                    break;
                case 5:

                    restaDiasDeMes = 31 - dia;
                    sumaDiasDeMes = restaDiasDeMes + 30 + 31 + 31 + 30 + 31 + 30 + 31;
                    System.out.println(sumaDiasDeMes);
                    break;
                case 6:

                    restaDiasDeMes = 30 - dia;
                    sumaDiasDeMes = restaDiasDeMes + 31 + 31 + 30 + 31 + 30 + 31;
                    System.out.println(sumaDiasDeMes);
                    break;
                case 7:

                    restaDiasDeMes = 31 - dia;
                    sumaDiasDeMes = restaDiasDeMes + 31 + 30 + 31 + 30 + 31;
                    System.out.println(sumaDiasDeMes);
                    break;
                case 8:

                    restaDiasDeMes = 31 - dia;
                    sumaDiasDeMes = restaDiasDeMes + 30 + 31 + 30 + 31;
                    System.out.println(sumaDiasDeMes);
                    break;
                case 9:

                    restaDiasDeMes = 30 - dia;
                    sumaDiasDeMes = restaDiasDeMes + 31 + 30 + 31;

                    System.out.println(sumaDiasDeMes);
                    break;
                case 10:

                    restaDiasDeMes = 31 - dia;
                    sumaDiasDeMes = restaDiasDeMes + 30 + 31;
                    resultado = año - sumaDiasDeMes;
                    System.out.println(resultado);
                    break;
                case 11:
                    restaDiasDeMes =  30 - dia;
                    sumaDiasDeMes = restaDiasDeMes + 31;
                    System.out.println(sumaDiasDeMes);
                    break;
                case 12:

                    restaDiasDeMes = 31 - dia;
                    sumaDiasDeMes = restaDiasDeMes;
                    System.out.println(sumaDiasDeMes);
                    break;

            }

        }
    }
}
