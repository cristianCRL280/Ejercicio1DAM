/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package EjerciciosAceptaElRetoNivel1;

import java.util.Scanner;

/**
 *
 * @author dev
 */
public class Ejercicio9 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int nVeces, nInsectos, nAracnidos, nCrustaceos, nEscolopendras, nAnillosEscolopendras;

        nVeces = sc.nextInt();
        for (int i = 0; i < nVeces; i++) {

            nInsectos = sc.nextInt();
            nAracnidos = sc.nextInt();
            nCrustaceos = sc.nextInt();
            nEscolopendras = sc.nextInt();
            nAnillosEscolopendras = sc.nextInt();

            int resultadoInsectos = nInsectos * 6;
            int resultadoAracnidos = nAracnidos * 8;
            int resultadoCrustaceos = nCrustaceos * 10;
            int resultadoAnillos = nAnillosEscolopendras * 2;
            int resultadoEscolopendras = nEscolopendras * resultadoAnillos;
           
            int resultadoTotal = resultadoInsectos + resultadoAracnidos + resultadoCrustaceos + resultadoEscolopendras;
            
            System.out.println(resultadoTotal);
            
            

        }

    }
}
