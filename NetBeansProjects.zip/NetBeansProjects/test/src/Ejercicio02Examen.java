
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
//Dos números enteros son colegas si el resultado de su suma es un tercer número que tiene todas sus cifras
//iguales.
//Escribe un programa java (Ejercicio02.java) que pida dos números enteros al usuario y como salida muestre si
//son o no números colegas. Es obligatorio implementar un método que reciba como parámetros dos números
//enteros y devuelva como resultado un boolean (que indica si son colegas los números recibidos). (3 puntos)
//Haz esta acción hasta que los dos números introducidos por el usuario sean cero. (0,5 puntos)
/**
 *
 * @author dev
 */
public class Ejercicio02Examen {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n1, n2;
        do {

            System.out.print("Introduce un número: ");
            n1 = sc.nextInt();
            System.out.print("Introduce otro número: ");
            n2 = sc.nextInt();
            if (n1 != 0 && n2 != 0) {

                boolean co = esColegas(n1, n2);
                if (co == true) {
                    System.out.println("Son colegas");
                }
                if (co == false) {
                    System.out.println("No son colegas");
                }

            }

        } while (n1 != 0 && n2 != 0);

    }

    public static boolean esColegas(int n1, int n2) {
        int suma = n1 + n2;
        String longitud = Integer.toString(suma);
        boolean b = true;
        for (int i = 0; i < longitud.length() - 1; i++) {

            if (longitud.charAt(i) == longitud.charAt(i + 1)) {
                b = true;
            } else {
                b = false;
                break;

            }

        }

        return false;
    }
}
