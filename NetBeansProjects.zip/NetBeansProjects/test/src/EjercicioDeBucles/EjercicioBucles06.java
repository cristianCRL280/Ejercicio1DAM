/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicios;

import java.util.Scanner;
//6. Programa que pida un valor real relativo al radio de circunferencias y calcule y
// muestre el área de la circunferencia correspondiente. El programa debe repetir esta
// acción hasta que el radio que introduzca el usuario sea menor o igual a cero.

/**
 *
 * @author dev
 */
public class EjercicioBucles06 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        double radio;
        double area;
        for (int i = 0;; i++) {

            System.out.println("Dame el radio de la circunferencia: ");
            radio = sc.nextDouble();
            
            area = 2 * 3.14 * radio; 
            System.out.println("El area es: " + area);
            
            
            if (radio <= 0) {
                
                break;
                
            }
            
        }

    }

}
