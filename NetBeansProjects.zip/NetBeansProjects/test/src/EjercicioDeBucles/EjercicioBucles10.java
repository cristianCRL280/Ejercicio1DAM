/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicios;

//10. Programa que pida datos desde teclado relativos a un conteo de coches por hora
//que han pasado por una vía durante 24 horas y realice los siguientes cálculos (Las
// horas para el usuario del programa van desde la 0 hasta la 23):
//○ Total de coches que pasaron en el día.
//○ Número de horas de tránsito cero.
//○ Última hora a la que pasó un coche.
import java.util.Scanner;

/**
 *
 * @author dev
 */
public class EjercicioBucles10 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        double hora = 0;
        int TotalCoches = 0;
        int coches;
        double HorasSinTransito = 0;
        double UltimaHora;
        double horas;

        for (; hora <= 23; hora++) {

            System.out.println("Numero de coches en la hora: " + hora);

            coches = sc.nextInt();

            if (coches == 0) {

                HorasSinTransito++;
                horas = hora + 1;

                System.out.println(hora);

            } else {

                UltimaHora = coches;
                TotalCoches = TotalCoches + coches;

                System.out.println("total coches: " + TotalCoches);
                System.out.println("Numero de coches en la ultima hora: " + UltimaHora);

            }
            System.out.println("Horas sin transito: " + HorasSinTransito);
        }

    }

}
