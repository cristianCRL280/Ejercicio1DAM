/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicios;

import java.util.Scanner;

//7. Programa que pida las notas de 20 alumnos de una clase y escriba la nota media de
//la clase
/**
 *
 * @author dev
 */
public class EjercicioBucles07 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int NumeroNotas = 20;
        double notas;
        double media;
        double sumaNotas = 0;

        for (int i = 1; i <= NumeroNotas; i++) {

            System.out.println("Introduzca la nota del alumno" + i);

            notas = sc.nextDouble();
            sumaNotas = sumaNotas + notas;
            
            media = sumaNotas / NumeroNotas;
            System.out.println("La nota media es " + media);

        }

    }
}
