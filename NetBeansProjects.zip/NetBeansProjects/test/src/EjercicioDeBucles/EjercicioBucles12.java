/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicios;
//1.- Hacer un programa que pida al usuario un texto y que posteriormente lo muestre por pantalla separando los caracteres en líneas. Tal y como se ve en este ejemplo:
//Introduzca un texto: Hola

import java.util.Scanner;

//H
//o
//l
//a
/**
 *
 * @author dev
 */
public class EjercicioBucles12 {
    public static void main(String[] args) {
        
        String str1;
    
         Scanner sc = new Scanner(System.in);
         System.out.println("Introduce el texto");
         
         str1 = sc.next();
        
         for (int i = 0; i < str1.length(); i++) {
            
             System.out.println(str1.charAt(i));
             
        }
        
        
    }
    
}
