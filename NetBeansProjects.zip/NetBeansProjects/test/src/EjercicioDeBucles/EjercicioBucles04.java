/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicios;
//4. Programa que escriba la siguiente serie de números: 100, 95, 90, 85, 80,... 15,10,5.
////
/**
 *
 * @author dev
 */
public class EjercicioBucles04 {
    
    public static void main(String[] args) {
        
        
        for (int i = 105; i != 0; ) {
            if (true) {
                
                i = i - 5;
                
                
            }
 
            
            System.out.println(i);
            
        }
        
    }
    
    
}
