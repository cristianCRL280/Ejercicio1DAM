/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicios;

import java.util.Scanner;
//6.- Haz un programa que lea números enteros por teclado, uno por línea. No sabemos cuántos van a ser, pero la secuencia va a terminar con la palabra"fin", que actuará de centinela.
//Iremos sumando internamente los números y finalmente, imprimiremos el mensaje: "La suma de todos los números es XX". Ejemplo:
//Introduce un número: 8
//Introduce un número: 4
//Introduce un número: 9
//Introduce un número: fin
//La suma de todos los números es 21
/**
 *
 * @author dev
 */
public class EjercicioBucles17 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in); 
        String n;
        int numero;
        int suma = 0;
        for (int i = 0; ; i++) {
            
            System.out.println("Dame un numero(escribe fin para acabar): ");
            n = sc.nextLine();
            
            if (n.equals("fin")) {
                
               
                
                break;
                
            } numero = Integer.parseInt(n);
                
                suma = suma + numero;
                
                System.out.println(suma);
            
           
            
        }
      
        System.out.println("La suma es de todos los numeros es " + suma);
        
        
        
    }
}
