/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejemplos;

import java.util.Scanner;

/**
 *
 * @author dev
 */
public class Ejemplo13FOR {
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String str1 = "";
        System.out.println("Dime el numero de veces a iterar: ");
        int n = sc.nextInt();
        
        for (int i= 0; i < n; i++) {
            str1 = str1 + "hola";
            System.out.println("i + " + str1);
        }
        
        String str2 = "adios";
        for (int i = 0; i < str2.length(); i++) {
            
            System.out.println(str2.charAt(i));
            
            
        }
        
//        for (;;) {
//            System.out.println("Infinito");
//        }
    }
    
}
