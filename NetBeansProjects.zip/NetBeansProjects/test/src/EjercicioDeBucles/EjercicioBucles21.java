/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicios;
//10.- Escribe un programa que pida un texto al usuario y muestre por pantalla ese mismo texto haciendo que la primera letra del texto sea mayúscula, la segunda minúscula y así sucesivamente. Repite esta acción hasta que el usuario introduzca la palabra fin. Ejemplo:
//Introduce un texto: Hola
//Salida: HoLa
//Introduce un texto: aDios
//Salida: AdIoS
//Introduce un texto: fin
import java.util.Scanner;

/**
 *
 * @author dev
 */
public class EjercicioBucles21 {
    
     public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        String texto, textoSalida;
       

        do {

            System.out.println("Introduzca un texto: ");
            texto = sc.nextLine();
            if (!texto.equalsIgnoreCase("fin")) {
                
                textoSalida = convertir(texto);
                System.out.println(textoSalida);

              
          
            }
        } while (!texto.equalsIgnoreCase("fin"));
         System.out.println("Adios!!");
    }
    
     
     public static String convertir (String texto) {
         
         String resultado = "";
         for (int i = 0; i < texto.length(); i++) {
             
             if (i % 2 == 0){
                 resultado = resultado + Character.toUpperCase(texto.charAt(i));
                 
             } else {
                  resultado = resultado + Character.toLowerCase(texto.charAt(i));
             }
             
         }
         return resultado;
     }
}
