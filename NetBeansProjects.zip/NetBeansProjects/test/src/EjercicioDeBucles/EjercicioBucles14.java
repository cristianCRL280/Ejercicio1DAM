/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicios;
//3.- Escribe un programa que pida por teclado 10 enteros, con el mensaje, “Dame el entero X:”. (siendo X 1, 2, 3...) Al final, tu programa debe decir: 
//Hay XX positivos. Hay XX negativos. Hay XX ceros.

import java.util.Scanner;

///**
// *
// * @author dev
// */
public class EjercicioBucles14 {
 
 public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        int n, nPositivos = 0, nNegativos = 0, nCeros = 0;
        for (int i = 1; i <= 10; i++) {
            
            System.out.println("Introduzca un numero: " + i);
            
            n = sc.nextInt();
         
            if (n > 0) {
                
                nPositivos = nPositivos + 1;
                
                
            } if (n == 0) {
                
                nCeros = nCeros + 1;
                
     } if (n < 0) {
                
                nNegativos = nNegativos + 1;
    }
        
            
        
    }
    System.out.println("Los numeros negativos son: " + nNegativos);
    System.out.println("Los numeros positivos son: " + nPositivos);
    System.out.println("Los numeros de ceros son: " + nCeros);
    
    
}}
