/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicios;

import java.util.Scanner;
//8.- Haz un programa que busque si entre los números enteros 1000 a 2000 (inclusive), hay alguno que sea simultáneamente múltiplo de 2, de 5 y de 7.
//En ese caso, al encontrarlo, el programa debe terminar sin buscar más, e imprimir el número.
//Si no se encuentra ninguno, el programa debe imprimir "NINGUNO".

/**
 *
 * @author dev
 */
public class EjercicioBucles19 {

    public static void main(String[] args) {
        int numero = -1;

        for (int i = 1000; i <= 2000; i++) {
            if (i % 2 == 0 && i % 5 == 0 && i % 7 == 0) {

                numero = i;
                break;

            }

        }
       
        if (numero == -1) {
            
            System.out.println("Ninguno");
            
        } else {
            
            System.out.println("Encontrado: " + numero);
        }
    }
}
