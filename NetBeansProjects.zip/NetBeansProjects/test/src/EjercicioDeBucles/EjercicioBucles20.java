/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicios;

/**
 *
 * @author dev
 */
public class EjercicioBucles20 {
    
    public static void main(String[] args) {
        
        int c2, c3;
        for (int i = 2; i < 9; i++) {
            
            c2 = 10 - i; 
            c3 = i % 2;
            
            System.out.println(i + "" + c2 + "" + c3);
            
        }
    }
    
}
