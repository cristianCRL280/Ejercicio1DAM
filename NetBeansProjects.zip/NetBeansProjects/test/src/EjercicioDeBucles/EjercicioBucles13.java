/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicios;

import java.util.Scanner;



//
////2.- Pide un número entero y positivo por pantalla en una variable int numero e imprime 
//la suma de todos los números comprendidos entre el 1 y ese número (inclusive)
//Es decir, si el número introducido es 5, el programa debe imprimir 15, que es la suma de 1+2+3+4+5
//Hazlo mediante un bucle for o un bucle while.
/**
 *
 * @author dev
 */
public class EjercicioBucles13 {
    public static void main(String[] args) {
        
         Scanner sc = new Scanner(System.in);
        
      int j;
      
        
        System.out.println("Introduce un numero");
        
        j = sc.nextInt();
        
        sumarNaturalesHasta(j);
        
        
        
        
       
         
    }
    public static void sumarNaturalesHasta(int n) {
        
        int resultado = 0;
        
        for (int i = 1; i <= n; i++) {
            
            System.out.println(i);
            
            resultado = resultado + i;
            
        }
        System.out.println("" + resultado);
    }
    
    
}
