/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicios;

import java.util.Scanner;

//5.- Dado un entero n, ve sucesivamente dividiéndolo por 3, e imprimiendo el cociente mientras éste cociente sea mayor o igual que 3. Muestra finalmente la cantidad de veces que se ha realizado la acción.Ejemplo:
//Introduce un número: 36
//12
//4
//1
//Se ha realizado la acción un total de 3 veces
/**
 *
 * @author dev
 */
public class EjercicioBucles16 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int numero , contador = 0;
        System.out.println("Dame un numero entero");
        numero = sc.nextInt();
        
        
        while (numero >= 3) {
            
           int cociente = numero / 3;
            contador++;
            System.out.println(numero);
            numero = cociente;
        }
        System.out.println("el resultado es " + numero);
        System.out.println("La accion se ha realizado: " + contador + " veces");
      

    }

}
