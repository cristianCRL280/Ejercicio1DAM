/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicios;
//Programa que escriba los números pares del 2 al 100.

/**
 *
 * @author dev
 */
public class EjercicioBucles03 {
    public static void main(String[] args) {
        for (int i = 2; i < 100; ) {
            
            if (true) {
                
                i = i + 2;
                
                
                
            }
            System.out.println(i);
            
        }
              
    }
}
