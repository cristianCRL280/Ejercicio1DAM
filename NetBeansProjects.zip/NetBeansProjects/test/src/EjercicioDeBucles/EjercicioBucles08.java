/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicios;
//8. Programa que pida valores enteros relativos a edades de 20 alumnos y cuente
// cuántos alumnos son mayor de edad.

import java.util.Scanner;

/**
 *
 * @author dev
 */
public class EjercicioBucles08 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int NumeroAlumnos = 20;
        int edad;
        int TotalMayorEdad = 0;

        for (int i = 1; i <= NumeroAlumnos; i++) {

            System.out.println("Introduzca la edad del alumno" + i);

            edad = sc.nextInt();

            if (edad >= 18) {

                TotalMayorEdad = TotalMayorEdad + 1;

            }

            System.out.println("Personas mayores de edad" + TotalMayorEdad);

        }

    }
}
