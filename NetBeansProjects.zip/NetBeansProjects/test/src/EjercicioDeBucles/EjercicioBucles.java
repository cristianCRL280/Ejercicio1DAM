/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
//package Ejercicios;
//1. Programa que escriba 10 veces la palabra hola.
/**
 *
 * @author dev
 */
public class EjercicioBucles {
    public static void main(String[] args) {
 
   
        for (int i = 0; i < 10; i++) {
            
            System.out.println("hola " + i);
        }
    
        
        
    }
    
    
}
