/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicios;

import java.util.Scanner;

//11. Una Ferretería vende dos tipos de Cables,
//○ Cable Tipo A (2,75 €. metro)
//○ Cable Tipo B (3,5 €. metro )
//
//Realiza un programa que pida estos datos:
//● Nombre del cliente
//○ Metros de tipo de cable A requeridos
//○ Metros de tipo de cable B requeridos
//
//Posteriormente debe mostrar el nombre del cliente y precio total a pagar, teniendo 
//en cuenta que la empresa da una rebaja del 10% por cada compra que exceda de
//los 100 metros (en suma de los dos tipos de cable).
//Finalmente debe preguntar al usuario “¿Hay más clientes?”. Si la respuesta es “SI”
//debe volver a pedir los datos.
/**
 *
 * @author dev
 */
public class EjercicioBucles11 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Scanner sl = new Scanner(System.in);
        String str1;
        int cableA;
        int cableB;
        int TotalMetros;
        String str2;

        do {
            double PrecioCableA;
            double PrecioCableB;
            double TotalEuros;

            System.out.println("Dime el nombre: ");

            str1 = sc.nextLine();

            System.out.println("Dime los metros de cableA q necesitas: ");
            cableA = sl.nextInt();

            System.out.println("Dime los metros de cableB q necesitas: ");
            cableB = sl.nextInt();

            System.out.println("Hola" + str1);

            TotalMetros = cableA + cableB;
            System.out.println("El total de metros de cable es: " + TotalMetros);

            if (TotalMetros >= 100) {

                PrecioCableA = (cableA * 2.75d) * 0.9;

                PrecioCableB = (cableB * 3.5d) * 0.9;

            } else {

                PrecioCableA = cableA * 2.75;
                PrecioCableB = cableB * 3.5;

            }

            TotalEuros = PrecioCableA + PrecioCableB;

            System.out.println("El precio entre los dos cables es: " + TotalEuros);
            
            System.out.println("¿Hay mas clientes?Si/No: ");
            str2 = sc.nextLine();

        } while (str2.equals("si"));
        {
            
        }

    }
}
