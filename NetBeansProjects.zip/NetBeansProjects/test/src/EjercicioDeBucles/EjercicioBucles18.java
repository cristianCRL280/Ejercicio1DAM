/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicios;

import java.util.Scanner;
//7.- Haz un programa que pida a un usuario un texto y cuente la cantidad de vocales que tiene el texto. Repite esta acción hasta que el usuario introduzca la palabra fin. Ejemplo:
//Introduzca un texto: Aire fresco por favor
//Salida: 8
//Introduzca un texto: fin
//Adios!!!

/**
 *
 * @author dev
 */
public class EjercicioBucles18 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        String texto;
        int contador;

        do {

            System.out.println("Introduzca un texto: ");
            texto = sc.nextLine();
            if (!texto.equalsIgnoreCase("fin")) {
                contador = 0;
                texto = texto.toLowerCase();
                for (int i = 0; i < texto.length(); i++) {

                    if (texto.charAt(i) == 'a' || texto.charAt(i) == 'e' || texto.charAt(i) == 'i'
                            || texto.charAt(i) == 'o' || texto.charAt(i) == 'u') {

                        contador++;
                    }

                }
                System.out.println("Numero de letras vocales " + contador);
            }
        } while (!texto.equalsIgnoreCase("fin"));

    }
}
