/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
//4- Escribe un programa que muestre por pantalla la tabla de multiplicar de un número cualquiera. Utiliza un bucle for, que cuente desde 0 hasta 10. Utiliza los valores del índice para imprimir cada línea. Ejemplo:
//¿De qué número quieres que saque la tabla?: 5
//5x0=0
//5x1=5
//5x2=10
//5x3=15
//5x4=20
//5x5=25
//5x6=30
//5x7=35
//5x8=40
//5x9=45
//5x10=50
package Ejercicios;

import java.util.Scanner;

/**
 *
 * @author dev
 */
public class EjercicioBucles15 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n , r;
        
         System.out.println("De que numero quieres q te haga la tabla de multiplicar: ");
              
            n = sc.nextInt();
        
        for (int i = 0; i <= 10; i++) {

           
            
            r = n * i;
            
            System.out.println(n +  " x " + i  + " = " + r );
           
            
        }

       
        
    }
}
