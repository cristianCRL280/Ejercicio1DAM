/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicios;
//5. Programa que pida el número de artículos que se han comprado, posteriormente 
//pida el precio de cada uno de ellos y finalmente muestre un mensaje con el valor

import java.util.Scanner;

// total de la compra.
/**
 *
 * @author dev
 */
public class EjercicioBucles05 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int Narticulos;
        double precio;
        double total;
        
        for (int i = 0; ; i++) {
            
        System.out.println("Dame un numero de articulo (pulse 0 para cancelar): ");
               Narticulos = sc.nextInt();
        
            if ( Narticulos == 0) {
                
               break;
                
            }
             System.out.println("Dame el precio");
               
               precio = sc.nextDouble();
               
            total = precio + precio;
            System.out.println("El total es: " + total);
        }
        
        

    }

}
