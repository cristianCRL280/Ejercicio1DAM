/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicios;

import java.util.Scanner;
//9. Programa que lea las notas de 20 alumnos de una clase y escriba por cada uno
//“APROBADO” o “SUSPENSO” si la nota es mayor o igual a cinco, o menor que 5
// respectivamente.

/**
 *
 * @author dev
 */
public class Ejercicio09Bucles {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int NumeroAlumnos = 20;
        double Nota;

        for (int i = 1; i <= NumeroAlumnos; i++) {

            System.out.println("Introduzca la nota del alumno");

            Nota = sc.nextDouble();

            if (Nota >= 5) {

                System.out.println("Aprobado");

            } else {
                System.out.println("Suspenso");
                
                
            }

            
        }

    }

}
