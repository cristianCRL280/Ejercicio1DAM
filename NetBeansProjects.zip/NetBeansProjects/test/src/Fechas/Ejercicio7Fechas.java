/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Fechas;

import java.time.LocalDate;

/**
 *
 * @author dev
 */
public class Ejercicio7Fechas {
    public static void main(String[] args) {
        LocalDate fNac = LocalDate.parse("1976-09-20");
        LocalDate hoy = LocalDate.now();
        long dias = hoy.toEpochDay() - fNac.toEpochDay();
        System.out.println("Dias que he vivido: " + dias);
        
        
        
        
    }
    
}
