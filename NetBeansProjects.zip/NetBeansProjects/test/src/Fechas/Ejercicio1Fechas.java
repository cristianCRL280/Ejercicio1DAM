/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Fechas;
//1.- Obtén qué fecha será dentro de 15 días, dentro de 30 y dentro de 45.
import java.time.LocalDate;

/**
 *
 * @author dev
 */
public class Ejercicio1Fechas {
    public static void main(String[] args) {
        
        LocalDate hoy = LocalDate.now();
        LocalDate hoyMas15 = hoy.plusDays(15);
        System.out.println(hoyMas15);
        LocalDate hoyMas30 = hoy.plusDays(30);
        System.out.println(hoyMas30);
        LocalDate hoyMas45 = hoy.plusDays(45);
        System.out.println(hoyMas45);
        
        
        
    }
}
