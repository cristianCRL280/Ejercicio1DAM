/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Fechas;

//2.- Obtén qué fecha fue hace 15 días y hace 30. 

import java.time.LocalDate;

/**
 *
 * @author dev
 */
public class Ejercicio2Fechas {
    public static void main(String[] args) {
        LocalDate hoy = LocalDate.now();
        System.out.println(hoy.plusDays(-15));
        System.out.println(hoy.minusDays(30));
        
    }
}
