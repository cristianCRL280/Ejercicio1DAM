/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Fechas;
//
//5.- ¿Cuántos días nos quedan del mes en el que estamos? 

import java.time.LocalDate;

/**
 *
 * @author dev
 */
public class Ejercicio5Fechas {
    public static void main(String[] args) {
        LocalDate hoy = LocalDate.now();
        System.out.println(hoy.lengthOfMonth() - hoy.getDayOfMonth());
        
        
        
    }
}
