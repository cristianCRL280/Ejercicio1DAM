/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Fechas;

import java.time.LocalDate;
import java.time.Period;
//- Suponiendo que el curso termine el 26 de Junio. ¿Cuántos días de curso nos quedan? -Contando la actual y la del 26 de Junio-. Consulta el API de LocalDate, a ver si podemos saber en qué día del año estamos
/**
 *
 * @author dev
 */
public class Ejercicio4Fechas {
    public static void main(String[] args) {
        LocalDate hoy = LocalDate.now();
        LocalDate fin = LocalDate.parse("2022-06-26");
        
        long dias = fin.toEpochDay() - hoy.toEpochDay();
        System.out.println(dias);
        
        Period p = Period.between(hoy, fin);
        System.out.println("años: " +  p.getYears());
         System.out.println("meses: " +  p.getMonths());
          System.out.println("dias: " +  p.getDays());
          
          
        
    }
    
}
