/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Fechas;

import java.time.LocalDate;

/**
 *
 * @author dev
 */
public class Ejercicio8Fechas {
    public static void main(String[] args) {
        
        LocalDate fNac = LocalDate.parse("1970-10-22");
        LocalDate hoy = LocalDate.now();
        LocalDate fCumple = fNac.withYear(hoy.getYear());
        System.out.println(fCumple);
        if (hoy.isBefore(fCumple)) {
            
            System.out.println("No ha pasado tu cumpleaños");
            
            
        } else if (hoy.equals(fCumple)){
            System.out.println("Enhorabuena... hoy es tu cumpleaños");
            
        } else if (hoy.isAfter(fCumple)){
            System.out.println("Ya ha pasado tu cumpleaños");
            
        }
        
        
    }
}
