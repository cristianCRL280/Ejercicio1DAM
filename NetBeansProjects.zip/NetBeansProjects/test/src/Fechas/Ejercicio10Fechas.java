/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Fechas;
//10.- En una empresa se celebra la renovación  del consejo de administración. 
//En la normativa de la empresa se recoge que el secretario es el miembro de menor edad del consejo.

import java.time.LocalDate;

////Para esto deberás tener dos arrays paralelos, uno con los nombres de los miembros del consejo y otro con sus fechas de nacimiento.
//Ayúdate de un método que reciba el array de las fechas de nacimiento 
//y que devuelva la posición del array en el que se encuentra la fecha más próxima a la actual (la fecha de nacimiento del menor).
//
//public static int posicionDelSecretario(LocalDate[] fechasNacimiento)
/**
 *
 * @author dev
 */
public class Ejercicio10Fechas {
    public static void main(String[] args) {
        
        String[] nConsejo = {"Pepe, juan, luis, maria, josefa"};
        LocalDate[] fConsejo = {
            LocalDate.parse("2002-07-26"),
            LocalDate.parse("1999-01-26"),
            LocalDate.parse("1973-02-26"),
            LocalDate.parse("1990-12-26"),
            LocalDate.parse("1995-04-26"),
        };
        
            
        
        
        int posicionSecretario =  posicionDelSecretario(fConsejo);
        
        System.out.println("El secretario es: " + nConsejo[posicionSecretario]);
        System.out.println("Y su fecha de nacimiento es " + fConsejo[posicionSecretario]);
        
        
        }
        

        
        
    
    
    
    public static int posicionDelSecretario(LocalDate[] fConsejo){
        
        int posicion = 0;
        
        LocalDate menor = fConsejo[0];
        
        for (int i = 1; i < fConsejo.length; i++) {
            if(fConsejo[i].isAfter(menor)){
                posicion = i;
                menor = fConsejo[i];
                
            }
            
        }
        
        
        return posicion;
    }
}
