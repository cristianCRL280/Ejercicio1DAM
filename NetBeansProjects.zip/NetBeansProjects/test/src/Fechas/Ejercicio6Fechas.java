/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Fechas;
//6.-  ¿Qué mes será dentro de 200 días?

import java.time.LocalDate;


/**
 *
 * @author dev
 */
public class Ejercicio6Fechas {
    public static void main(String[] args) {
          LocalDate fecha = LocalDate.now().plusDays(200);
          String mes = fecha.getMonth().toString();
          System.out.println(mes);
          
        
        
        
    }
    
}
