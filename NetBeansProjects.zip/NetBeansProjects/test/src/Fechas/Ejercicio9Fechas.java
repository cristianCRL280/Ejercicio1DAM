/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Fechas;

import java.time.LocalDate;
import java.time.Period;
import java.util.Scanner;

/**
 *
 * @author dev
 */
public class Ejercicio9Fechas {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Introduzca un nombre: ");
        String nombre1 = sc.nextLine();
        System.out.println("Introduzca la fecha de nacimiento (dd//mm/aaaa)");
        String fecha1 = sc.nextLine();
        String[] datosFecha1 = fecha1.split("/");

        int dia1 = Integer.parseInt(datosFecha1[0]);

        int mes1 = Integer.parseInt(datosFecha1[1]);

        int anyo1 = Integer.parseInt(datosFecha1[2]);
        LocalDate fNac1 = LocalDate.of(anyo1, mes1, dia1);
        Period p1 = Period.between(fNac1, LocalDate.now());
        anyo1 = p1.getYears();

        System.out.println("Introduzca un nombre: ");
        String nombre2 = sc.nextLine();
        System.out.println("Introduzca la fecha de nacimiento (dd//mm/aaaa)");
        String fecha2 = sc.nextLine();
        String[] datosFecha2 = fecha2.split("/");

        int dia2 = Integer.parseInt(datosFecha2[0]);

        int mes2 = Integer.parseInt(datosFecha2[1]);

        int anyo2 = Integer.parseInt(datosFecha2[2]);
        LocalDate fNac2 = LocalDate.of(anyo2, mes2, dia2);
        Period p2 = Period.between(fNac2, LocalDate.now());
        anyo2 = p2.getYears();

        if (fNac2.isAfter(fNac1)) {
            System.out.println(nombre2 + "es mas joven que " + nombre1);

        } else if (fNac2.isBefore(fNac1)) {

            System.out.println(nombre1 + "es mas joven que " + nombre2);

        } else {

            System.out.println("Tienen la misma edad");
        }
        System.out.println(nombre1 + " tiene " + p1.getYears() + " años " + p1.getMonths() + " meses y " + p1.getDays() + " dias ");
        System.out.println(nombre2 + " tiene " + p2.getYears() + " años " + p2.getMonths() + " meses y " + p2.getDays() + " dias ");

    }

}
