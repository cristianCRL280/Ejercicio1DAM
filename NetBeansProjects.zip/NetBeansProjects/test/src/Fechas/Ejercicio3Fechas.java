/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Fechas;

//3.-  Donald Knuth nació el 10 de Enero de 1938. ¿Qué día de la semana fue?

import java.time.LocalDate;
import java.time.Month;


/**
 *
 * @author dev
 */
public class Ejercicio3Fechas {
    public static void main(String[] args) {
//         LocalDate fNacDK = LocalDate.parse("1938-01-10");
          LocalDate fNacDK = LocalDate.of(1938, 1, 10);
          System.out.println(fNacDK);
    }
    
}
