/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MetodoStaticEjemplo1;

/**
 *
 * @author dev
 */
public class UtilConversor {
       public static double kmToMi(double km){
        return km * 0.621371d;
        
    }
    
    public static double miToKm(double mi){
        
        return mi * 1.68934d;
        
    }
}
