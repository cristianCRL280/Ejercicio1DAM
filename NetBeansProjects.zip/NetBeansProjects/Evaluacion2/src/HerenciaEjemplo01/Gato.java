/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package HerenciaEjemplo01;

/**
 *
 * @author dev
 */
public class Gato extends Animal{
    double largo0rejas;

    @Override
    public String toString() {
        return super.toString() + "Gato{" + "largo0rejas=" + largo0rejas + '}';
    }
    
    
}
