/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MaquinaDeHelados;

import java.util.Scanner;

/**
 *
 * @author dev
 */
public class Exec {

    Scanner sc = new Scanner(System.in);
    MaquinaHelados mh = new MaquinaHelados();
    String opcion;
    Helado conseguido;
    String posicion = "";
//    do {
//            if (!opcion.equalsIgnoreCase("S")) {
//                
//                
//                
//                
//                
//                
//                
//                
//                
//                
//            }
//        
//    } while (!opcion.equalsIgnoreCase("S"));
//    

    public static void introDinero(MaquinaHelados mh, Scanner sc) {
        System.out.println("Introduce las monedas: ");
        double dinero = sc.nextDouble();

    }

//    public static double traducirDinero(String opcion){
//        
//    }
    public static void mostrarMonedas() {

    }

    public static void mostrar(MaquinaHelados mh) {

        
        
        
        
        
        
    }

    public static void salir(MaquinaHelados mh) {

    }
//    public static String menu(Scanner sc){
//        
//    }
}
