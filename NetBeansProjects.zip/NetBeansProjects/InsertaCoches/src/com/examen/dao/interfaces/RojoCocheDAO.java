/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.examen.dao.interfaces;

import com.examen.pojo.Coche;
import java.util.ArrayList;

/**
 *
 * @author dev
 */
public interface RojoCocheDAO {
      public int insertarCochesRojos(Coche c) throws Exception;
}
