/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.examen2.utils;

/**
 *
 * @author dev
 */
public class Utils {

    public static final String URL = "jdbc:sqlite:./casa.db";
    public static final String DRIVER = "org.sqlite.JDBC";
}
