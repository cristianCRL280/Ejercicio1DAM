/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.danielm.mh.exceptions;

/**
 *
 * @author Daniel Marin y Cristian Rodriguez
 */
public class ThereIsNotEnoughMoneyException extends Exception {
    public ThereIsNotEnoughMoneyException(String msg){
        super(msg);
    }
}
