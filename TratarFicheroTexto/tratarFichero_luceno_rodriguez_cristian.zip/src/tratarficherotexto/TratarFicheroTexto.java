/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tratarficherotexto;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Scanner;

/**
 *
 * @author dev
 */
public class TratarFicheroTexto {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String fichero = "";
        Scanner scFile = null;
        System.out.println("Introduce el fichero");
        fichero = sc.nextLine();
        String linea;
        char c;
        File fIni = new File(fichero);
        int contLineas = 0;
        int contCaracteres = 0;
        int suma = 0;
        if (!fIni.exists()) {
            System.out.println("no existe el fichero");;
        } else {
            try {
                scFile = new Scanner(fIni);
                while (scFile.hasNextLine()) {
                    linea = scFile.nextLine();
                    for (int i = 0; i < linea.length(); i++) {
                        if (Character.isDigit(linea.charAt(i))) {
                            contCaracteres++;
                            suma += Character.getNumericValue(linea.charAt(i));
                        }
                    }

                    contLineas++;
                }
                System.out.println("Numero de lineas " + contLineas);
                System.out.println("Total de caracteres numericos " + contCaracteres);
                System.out.println("Suma de los valores de los caracteres numericos " + suma);
            } catch (Exception e) {
                System.out.println("Error");
            } finally {
                if (scFile != null) {
                    try {
                        scFile.close();
                    } catch (Exception e) {
                        System.out.println("Error al cerrar el scFile");
                    }
                }
            }

        }
    }

}
