/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.examen.gui;

import com.examen.implementations.CocheDAOimpl;
import com.examen.pojo.Coche;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author dev
 */
public class Exec {

    public static void main(String[] args) throws Exception {
        Scanner sc = new Scanner(System.in);
        ArrayList<Coche> cs = new ArrayList<Coche>();
        String matricula;
        String marca;
        String modelo;
        String color;
        String volver;
        do {
         
                
            
            System.out.print("Matricula: ");
            matricula = sc.nextLine();
            System.out.print("Marca: ");
            marca = sc.nextLine();
            System.out.print("Modelo: ");
            modelo = sc.nextLine();
            System.out.print("Color: ");
            color = sc.nextLine();

            Coche coches = new Coche(matricula, marca, modelo, color);
            cs.add(coches);
            try (CocheDAOimpl c = new CocheDAOimpl()) {
                for (Coche coche : cs) {
                    if (color.equals("verde")) {
                        c.insertarCochesVerdes(cs);
                    } else if (color.equals("rojo")) {
                        c.insertarCochesRojos(cs);
                    } else if (!color.equals("verde") && !color.equals("rojo")) {
                        c.insertarRestoCoches(cs);
                    }
                }

            } catch (Exception e) {
                e.printStackTrace();
                e.getMessage();
            }
         
            System.out.println("Quieres volver a generar un coche?");
            volver = sc.nextLine();
            
        } while (volver.equals("si"));

    }

}
